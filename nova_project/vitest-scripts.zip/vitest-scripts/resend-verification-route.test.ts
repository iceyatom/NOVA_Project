import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const {
  generateVerificationCodeMock,
  getExpiryDateMock,
  getPrismaMock,
  hashVerificationCodeMock,
  prismaMock,
  sendVerificationEmailMock,
} = vi.hoisted(() => {
  const prisma = {
    account: {
      findUnique: vi.fn(),
    },
    pendingSignup: {
      findUnique: vi.fn(),
      update: vi.fn(),
    },
    pendingVerification: {
      upsert: vi.fn(),
    },
  };

  return {
    generateVerificationCodeMock: vi.fn(),
    getExpiryDateMock: vi.fn(),
    getPrismaMock: vi.fn(),
    hashVerificationCodeMock: vi.fn(),
    prismaMock: prisma,
    sendVerificationEmailMock: vi.fn(),
  };
});

vi.mock("@/lib/prisma", () => ({
  getPrisma: getPrismaMock,
}));

vi.mock("@/lib/auth/verificationCode", () => ({
  generateVerificationCode: generateVerificationCodeMock,
  getExpiryDate: getExpiryDateMock,
  hashVerificationCode: hashVerificationCodeMock,
}));

vi.mock("@/lib/email/emailService", () => ({
  sendVerificationEmail: sendVerificationEmailMock,
}));

import { POST } from "@/app/api/resend-verification/route";

const routeUrl = "http://localhost/api/resend-verification";
const now = new Date("2026-04-24T12:00:00.000Z");

function jsonRequest(body: Record<string, unknown>) {
  return new NextRequest(routeUrl, {
    method: "POST",
    body: JSON.stringify(body),
    headers: {
      "content-type": "application/json",
    },
  });
}

describe("/api/resend-verification route", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers();
    vi.setSystemTime(now);
    getPrismaMock.mockResolvedValue(prismaMock);
    generateVerificationCodeMock.mockReturnValue("123456");
    hashVerificationCodeMock.mockResolvedValue("hashed:123456");
    getExpiryDateMock.mockImplementation(
      (minutes = 15) => new Date(Date.now() + minutes * 60 * 1000),
    );
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it("rejects invalid JSON bodies", async () => {
    const response = await POST(
      new NextRequest(routeUrl, {
        method: "POST",
        body: "{",
        headers: {
          "content-type": "application/json",
        },
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body).toEqual({ ok: false, error: "Invalid JSON body." });
    expect(prismaMock.pendingSignup.findUnique).not.toHaveBeenCalled();
  });

  it("requires an email address", async () => {
    const response = await POST(jsonRequest({ email: "   " }));
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body).toEqual({ ok: false, error: "Email is required." });
    expect(prismaMock.pendingSignup.findUnique).not.toHaveBeenCalled();
  });

  it("returns a cooldown error when a pending signup cannot resend yet", async () => {
    const resendAvailableAt = new Date(Date.now() + 90_000);
    prismaMock.pendingSignup.findUnique.mockResolvedValue({
      email: "test@example.com",
      displayName: "Test User",
      resendAvailableAt,
    });

    const response = await POST(jsonRequest({ email: " Test@Example.com " }));
    const body = await response.json();

    expect(response.status).toBe(429);
    expect(body).toEqual({
      ok: false,
      error: "Please wait before requesting another verification code.",
      resendAvailableAt: resendAvailableAt.toISOString(),
      retryAfterSeconds: 90,
    });
    expect(prismaMock.pendingSignup.findUnique).toHaveBeenCalledWith({
      where: { email: "test@example.com" },
      select: {
        email: true,
        displayName: true,
        resendAvailableAt: true,
      },
    });
    expect(prismaMock.pendingSignup.update).not.toHaveBeenCalled();
    expect(sendVerificationEmailMock).not.toHaveBeenCalled();
  });

  it("updates pending signup verification data and sends a new code", async () => {
    const previousResendAvailableAt = new Date(Date.now() - 1_000);
    prismaMock.pendingSignup.findUnique.mockResolvedValue({
      email: "test@example.com",
      displayName: "Test User",
      resendAvailableAt: previousResendAvailableAt,
    });

    const response = await POST(jsonRequest({ email: " Test@Example.com " }));
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      ok: true,
      resendAvailableAt: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
    });
    expect(prismaMock.pendingSignup.update).toHaveBeenCalledWith({
      where: { email: "test@example.com" },
      data: {
        codeHash: "hashed:123456",
        expiresAt: new Date(Date.now() + 15 * 60 * 1000),
        resendAvailableAt: new Date(Date.now() + 5 * 60 * 1000),
      },
    });
    expect(sendVerificationEmailMock).toHaveBeenCalledWith(
      "test@example.com",
      "Test User",
      "123456",
    );
  });

  it("returns ok for unknown or non-pending accounts without sending email", async () => {
    prismaMock.pendingSignup.findUnique.mockResolvedValue(null);
    prismaMock.account.findUnique.mockResolvedValue({
      id: 12,
      email: "active@example.com",
      displayName: "Active User",
      status: "active",
    });

    const response = await POST(jsonRequest({ email: "active@example.com" }));
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({ ok: true });
    expect(prismaMock.pendingVerification.upsert).not.toHaveBeenCalled();
    expect(sendVerificationEmailMock).not.toHaveBeenCalled();
  });

  it("upserts a legacy pending verification and sends a new code", async () => {
    prismaMock.pendingSignup.findUnique.mockResolvedValue(null);
    prismaMock.account.findUnique.mockResolvedValue({
      id: 12,
      email: "pending@example.com",
      displayName: null,
      status: "pending",
    });

    const response = await POST(jsonRequest({ email: "pending@example.com" }));
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({ ok: true });
    expect(prismaMock.pendingVerification.upsert).toHaveBeenCalledWith({
      where: { accountId: 12 },
      update: {
        codeHash: "hashed:123456",
        expiresAt: new Date(Date.now() + 15 * 60 * 1000),
      },
      create: {
        accountId: 12,
        codeHash: "hashed:123456",
        expiresAt: new Date(Date.now() + 15 * 60 * 1000),
      },
    });
    expect(sendVerificationEmailMock).toHaveBeenCalledWith(
      "pending@example.com",
      "there",
      "123456",
    );
  });
});
