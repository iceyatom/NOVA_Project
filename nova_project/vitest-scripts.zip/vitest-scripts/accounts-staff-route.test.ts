import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const { cookiesMock, prismaMock } = vi.hoisted(() => ({
  cookiesMock: vi.fn(),
  prismaMock: {
    session: {
      findUnique: vi.fn(),
    },
    account: {
      findMany: vi.fn(),
      findUnique: vi.fn(),
      update: vi.fn(),
      updateMany: vi.fn(),
    },
    alert: {
      create: vi.fn(),
    },
    $transaction: vi.fn(),
  },
}));

vi.mock("next/headers", () => ({
  cookies: cookiesMock,
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

vi.mock("@/lib/auth/passwordHash", () => ({
  hashPassword: vi.fn(async (password: string) => `hashed:${password}`),
}));

import {
  DELETE,
  GET,
  PATCH,
} from "@/app/api/accounts/staff/route";

type MockSessionRole = "ADMIN" | "STAFF" | "CUSTOMER";

const routeUrl = "http://localhost/api/accounts/staff";

function mockCookieToken(token?: string) {
  cookiesMock.mockResolvedValue({
    get: vi.fn((name: string) =>
      name === "session" && token ? { value: token } : undefined,
    ),
  });
}

function mockActiveSession(role: MockSessionRole, accountId = 1) {
  prismaMock.session.findUnique.mockResolvedValue({
    token: "session-token",
    expiresAt: new Date(Date.now() + 60_000),
    account: {
      id: accountId,
      role,
      status: "active",
      deletedAt: null,
    },
  });
}

function jsonRequest(
  method: "PATCH" | "DELETE",
  body: Record<string, unknown>,
) {
  return new NextRequest(routeUrl, {
    method,
    body: JSON.stringify(body),
    headers: {
      "content-type": "application/json",
    },
  });
}

describe("/api/accounts/staff route", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockCookieToken("session-token");
  });

  it("rejects requests without a staff session cookie", async () => {
    mockCookieToken();

    const response = await GET(new NextRequest(routeUrl));
    const body = await response.json();

    expect(response.status).toBe(401);
    expect(body).toEqual({ success: false, error: "Unauthorized." });
    expect(prismaMock.session.findUnique).not.toHaveBeenCalled();
  });

  it("lists active accounts with search, role filtering, sorting, and paging", async () => {
    mockActiveSession("STAFF");
    prismaMock.account.findMany.mockResolvedValue([
      {
        id: 2,
        displayName: "Beta Staff",
        email: "beta@example.com",
        phone: "5552223333",
        notes: null,
        role: "STAFF",
        createdAt: new Date("2024-01-02T00:00:00.000Z"),
        lastLoginAt: null,
      },
      {
        id: 1,
        displayName: "Alpha Admin",
        email: "alpha@example.com",
        phone: "5551112222",
        notes: "Can manage accounts",
        role: "ADMIN",
        createdAt: new Date("2024-01-01T00:00:00.000Z"),
        lastLoginAt: new Date("2024-02-01T00:00:00.000Z"),
      },
    ]);

    const request = new NextRequest(
      `${routeUrl}?role=admin&query=alpha&pageSize=1&offset=0&sortBy=email&sortOrder=asc`,
    );

    const response = await GET(request);
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toMatchObject({
      success: true,
      totalCount: 1,
      limit: 1,
      offset: 0,
      sortBy: "email",
      sortOrder: "asc",
      roleFilter: "ADMIN",
      query: "alpha",
    });
    expect(body.data).toHaveLength(1);
    expect(body.data[0]).toMatchObject({
      id: 1,
      displayName: "Alpha Admin",
      email: "alpha@example.com",
      phone: "5551112222",
      notes: "Can manage accounts",
      role: "ADMIN",
    });
    expect(prismaMock.account.findMany).toHaveBeenCalledWith({
      where: {
        deletedAt: null,
        role: "ADMIN",
      },
      select: {
        id: true,
        displayName: true,
        email: true,
        phone: true,
        notes: true,
        role: true,
        createdAt: true,
        lastLoginAt: true,
      },
    });
  });

  it("allows staff to read but rejects staff PATCH requests", async () => {
    mockActiveSession("STAFF");

    const response = await PATCH(
      jsonRequest("PATCH", {
        accountId: 2,
        role: "ADMIN",
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(403);
    expect(body).toEqual({ success: false, error: "Forbidden." });
    expect(prismaMock.account.update).not.toHaveBeenCalled();
  });

  it("validates PATCH input before updating an account", async () => {
    mockActiveSession("ADMIN");

    const response = await PATCH(
      jsonRequest("PATCH", {
        accountId: 2,
        phone: "123",
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body).toEqual({
      success: false,
      error: "Phone number is too short. Use exactly 10 digits.",
    });
    expect(prismaMock.account.findUnique).not.toHaveBeenCalled();
    expect(prismaMock.account.update).not.toHaveBeenCalled();
  });

  it("prevents admins from deleting their own account", async () => {
    mockActiveSession("ADMIN", 10);

    const response = await DELETE(
      jsonRequest("DELETE", {
        accountId: 10,
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body).toEqual({
      success: false,
      error: "You cannot delete your own account.",
    });
    expect(prismaMock.account.findUnique).not.toHaveBeenCalled();
  });
});
