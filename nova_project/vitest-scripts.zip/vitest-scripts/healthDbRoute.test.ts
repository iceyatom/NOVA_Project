import { describe, it, expect, vi, beforeEach } from "vitest";

const queryRawMock = vi.fn();

vi.mock("@/app/lib/prisma", () => ({
  prisma: {
    $queryRaw: queryRawMock,
  },
}));

describe("/api/health/db", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("returns ok:true when database query succeeds", async () => {
    queryRawMock.mockResolvedValueOnce([
      { now: new Date("2026-01-01T00:00:00Z") },
    ]);

    const route = await import("../src/app/api/health/db/route");
    const response = await route.GET();
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.ok).toBe(true);
    expect(body.time).toBeDefined();
  });

  it("calls prisma queryRaw with SELECT NOW query", async () => {
    queryRawMock.mockResolvedValueOnce([
      { now: new Date("2026-01-01T00:00:00Z") },
    ]);

    const route = await import("../src/app/api/health/db/route");
    await route.GET();

    expect(queryRawMock).toHaveBeenCalledTimes(1);
  });

  it("returns time as an array from Prisma", async () => {
    queryRawMock.mockResolvedValueOnce([
      { now: new Date("2026-01-01T00:00:00Z") },
    ]);

    const route = await import("../src/app/api/health/db/route");
    const response = await route.GET();
    const body = await response.json();

    expect(Array.isArray(body.time)).toBe(true);
  });

  it("returns first time object with now property", async () => {
    queryRawMock.mockResolvedValueOnce([
      { now: new Date("2026-01-01T00:00:00Z") },
    ]);

    const route = await import("../src/app/api/health/db/route");
    const response = await route.GET();
    const body = await response.json();

    expect(body.time[0]).toHaveProperty("now");
  });

  it("returns ok:false and 500 when database query fails", async () => {
    queryRawMock.mockRejectedValueOnce(new Error("DB failed"));

    const route = await import("../src/app/api/health/db/route");
    const response = await route.GET();
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.ok).toBe(false);
    expect(body.error).toBe("DB failed");
  });

  it("returns Unknown error when non-Error is thrown", async () => {
    queryRawMock.mockRejectedValueOnce("weird failure");

    const route = await import("../src/app/api/health/db/route");
    const response = await route.GET();
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.ok).toBe(false);
    expect(body.error).toBe("Unknown error");
  });
});