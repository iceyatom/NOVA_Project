import { describe, it, expect, vi, beforeEach } from "vitest";
import { NextRequest, NextResponse } from "next/server";

const requireStaffSessionMock = vi.fn();

const prismaMock = {
  $transaction: vi.fn(),
  ticket: {
    findMany: vi.fn(),
    count: vi.fn(),
    create: vi.fn(),
  },
  ticketLine: {
    createMany: vi.fn(),
  },
  account: {
    findMany: vi.fn(),
    findUnique: vi.fn(),
  },
  catalogItem: {
    findMany: vi.fn(),
    updateMany: vi.fn(),
  },
  alert: {
    create: vi.fn(),
  },
};

vi.mock("@/lib/db", () => ({
  prisma: prismaMock,
}));

vi.mock("@/lib/auth/staffAccess", () => ({
  requireStaffSession: requireStaffSessionMock,
}));

function makeRequest(url: string, body?: unknown) {
  return new NextRequest(url, {
    method: body ? "POST" : "GET",
    body: body ? JSON.stringify(body) : undefined,
    headers: body ? { "Content-Type": "application/json" } : undefined,
  });
}

function mockAuthorizedSession() {
  requireStaffSessionMock.mockResolvedValue({
    ok: true,
    session: {
      account: {
        id: 1,
        email: "staff@example.com",
        role: "STAFF",
      },
    },
  });
}

function mockUnauthorizedSession() {
  requireStaffSessionMock.mockResolvedValue({
    ok: false,
    response: NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 }),
  });
}

async function getRoute() {
  return await import("../src/app/api/tickets/staff/route");
}

describe("/api/tickets/staff", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("GET returns mapped tickets and summary for authorized staff", async () => {
    mockAuthorizedSession();

    const createdAt = new Date("2026-01-01T12:00:00Z");

    const tickets = [
      {
        id: 10,
        type: "ORDER",
        notes: "Order ticket",
        createdAt,
        createdByAccountId: 1,
        ticketLines: [
          {
            id: 100,
            catalogItemId: 5,
            countDelta: -2,
            catalogItem: {
              itemName: "Gloves",
              sku: "GLV-1",
              price: 12.5,
            },
          },
        ],
      },
    ];

    prismaMock.$transaction.mockResolvedValueOnce([tickets, 1, 0, 1, 0]);
    prismaMock.account.findMany.mockResolvedValueOnce([
      {
        id: 1,
        email: "staff@example.com",
        displayName: "Staff User",
      },
    ]);

    const route = await getRoute();
    const response = await route.GET(
      makeRequest("http://localhost/api/tickets/staff"),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.success).toBe(true);
    expect(body.tickets).toHaveLength(1);
    expect(body.tickets[0].id).toBe(10);
    expect(body.tickets[0].authorName).toBe("Staff User");
    expect(body.summary).toEqual({
      totalTickets: 1,
      supplyTickets: 0,
      orderTickets: 1,
      spoilageTickets: 0,
    });
  });

  it("GET accepts valid type filter and limit", async () => {
    mockAuthorizedSession();

    prismaMock.$transaction.mockResolvedValueOnce([[], 0, 0, 0, 0]);
    prismaMock.account.findMany.mockResolvedValueOnce([]);

    const route = await getRoute();
    const response = await route.GET(
      makeRequest("http://localhost/api/tickets/staff?limit=20&type=ORDER"),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.success).toBe(true);
    expect(prismaMock.$transaction).toHaveBeenCalledTimes(1);
  });

  it("GET rejects invalid type filter", async () => {
    mockAuthorizedSession();

    const route = await getRoute();
    const response = await route.GET(
      makeRequest("http://localhost/api/tickets/staff?type=INVALID"),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.success).toBe(false);
    expect(body.error).toBe("Ticket type filter is invalid.");
  });

  it("GET passes through unauthorized response", async () => {
    mockUnauthorizedSession();

    const route = await getRoute();
    const response = await route.GET(
      makeRequest("http://localhost/api/tickets/staff"),
    );
    const body = await response.json();

    expect(response.status).toBe(401);
    expect(body.success).toBe(false);
  });

  it("GET returns 500 when Prisma fetch fails", async () => {
    mockAuthorizedSession();

    prismaMock.$transaction.mockRejectedValueOnce(new Error("DB failed"));

    const route = await getRoute();
    const response = await route.GET(
      makeRequest("http://localhost/api/tickets/staff"),
    );
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.success).toBe(false);
    expect(body.error).toBe("Failed to fetch tickets.");
  });

  it("POST creates ORDER ticket successfully", async () => {
    mockAuthorizedSession();

    prismaMock.account.findUnique.mockResolvedValueOnce({
      id: 1,
      email: "staff@example.com",
      displayName: "Staff User",
      role: "STAFF",
      status: "active",
      deletedAt: null,
    });

    prismaMock.catalogItem.findMany.mockResolvedValueOnce([
      {
        id: 5,
        itemName: "Gloves",
        quantityInStock: 10,
        reorderLevel: 3,
      },
    ]);

    prismaMock.$transaction.mockImplementationOnce(async (callback) => {
      const tx = {
        ticket: {
          create: vi.fn().mockResolvedValue({
            id: 55,
            createdAt: new Date("2026-01-01T12:00:00Z"),
            type: "ORDER",
          }),
        },
        ticketLine: {
          createMany: vi.fn().mockResolvedValue({ count: 1 }),
        },
        catalogItem: {
          updateMany: vi.fn().mockResolvedValue({ count: 1 }),
          findMany: vi.fn().mockResolvedValue([
            {
              id: 5,
              itemName: "Gloves",
              quantityInStock: 8,
              reorderLevel: 3,
            },
          ]),
        },
        account: {
          findMany: vi.fn().mockResolvedValue([{ id: 99 }]),
        },
        alert: {
          create: vi.fn().mockResolvedValue({ id: 1 }),
        },
      };

      return callback(tx);
    });

    const route = await getRoute();
    const response = await route.POST(
      makeRequest("http://localhost/api/tickets/staff", {
        type: "ORDER",
        notes: "Order items",
        createdByEmail: "staff@example.com",
        lines: [{ catalogItemId: 5, countDelta: 2 }],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.success).toBe(true);
    expect(body.data.ticketId).toBe(55);
    expect(body.data.lineCount).toBe(1);
  });

  it("POST creates SUPPLY ticket successfully", async () => {
    mockAuthorizedSession();

    prismaMock.account.findUnique.mockResolvedValueOnce({
      id: 1,
      email: "staff@example.com",
      displayName: "Staff User",
      role: "STAFF",
      status: "active",
      deletedAt: null,
    });

    prismaMock.catalogItem.findMany.mockResolvedValueOnce([
      {
        id: 5,
        itemName: "Gloves",
        quantityInStock: 10,
        reorderLevel: 3,
      },
    ]);

    prismaMock.$transaction.mockImplementationOnce(async (callback) => {
      const tx = {
        ticket: {
          create: vi.fn().mockResolvedValue({
            id: 56,
            createdAt: new Date("2026-01-01T12:00:00Z"),
            type: "SUPPLY",
          }),
        },
        ticketLine: {
          createMany: vi.fn().mockResolvedValue({ count: 1 }),
        },
        catalogItem: {
          updateMany: vi.fn().mockResolvedValue({ count: 1 }),
          findMany: vi.fn().mockResolvedValue([
            {
              id: 5,
              itemName: "Gloves",
              quantityInStock: 15,
              reorderLevel: 3,
            },
          ]),
        },
        account: {
          findMany: vi.fn().mockResolvedValue([{ id: 99 }]),
        },
        alert: {
          create: vi.fn().mockResolvedValue({ id: 1 }),
        },
      };

      return callback(tx);
    });

    const route = await getRoute();
    const response = await route.POST(
      makeRequest("http://localhost/api/tickets/staff", {
        type: "SUPPLY",
        notes: "Supply items",
        createdByEmail: "staff@example.com",
        lines: [{ catalogItemId: 5, countDelta: 5 }],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body.success).toBe(true);
    expect(body.data.ticketId).toBe(56);
  });

  it("POST rejects invalid JSON body", async () => {
    mockAuthorizedSession();

    const badRequest = new NextRequest("http://localhost/api/tickets/staff", {
      method: "POST",
      body: "{ bad json",
    });

    const route = await getRoute();
    const response = await route.POST(badRequest);
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("Invalid JSON body.");
  });

  it("POST rejects invalid ticket type", async () => {
    mockAuthorizedSession();

    const route = await getRoute();
    const response = await route.POST(
      makeRequest("http://localhost/api/tickets/staff", {
        type: "BAD",
        notes: "Test notes",
        createdByEmail: "staff@example.com",
        lines: [{ catalogItemId: 1, countDelta: 1 }],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("Ticket type is invalid.");
  });

  it("POST rejects missing notes", async () => {
    mockAuthorizedSession();

    const route = await getRoute();
    const response = await route.POST(
      makeRequest("http://localhost/api/tickets/staff", {
        type: "ORDER",
        createdByEmail: "staff@example.com",
        lines: [{ catalogItemId: 1, countDelta: 1 }],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("Ticket notes are required.");
  });

  it("POST rejects missing creator email", async () => {
    mockAuthorizedSession();

    const route = await getRoute();
    const response = await route.POST(
      makeRequest("http://localhost/api/tickets/staff", {
        type: "ORDER",
        notes: "Test notes",
        lines: [{ catalogItemId: 1, countDelta: 1 }],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("Creator email is required.");
  });

  it("POST rejects empty ticket lines", async () => {
    mockAuthorizedSession();

    const route = await getRoute();
    const response = await route.POST(
      makeRequest("http://localhost/api/tickets/staff", {
        type: "ORDER",
        notes: "Test notes",
        createdByEmail: "staff@example.com",
        lines: [],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("At least one ticket line is required.");
  });

  it("POST rejects duplicate catalog items", async () => {
    mockAuthorizedSession();

    const route = await getRoute();
    const response = await route.POST(
      makeRequest("http://localhost/api/tickets/staff", {
        type: "ORDER",
        notes: "Test notes",
        createdByEmail: "staff@example.com",
        lines: [
          { catalogItemId: 1, countDelta: 1 },
          { catalogItemId: 1, countDelta: 2 },
        ],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("Duplicate catalog items are not allowed.");
  });

  it("POST rejects inactive or missing creator account", async () => {
    mockAuthorizedSession();

    prismaMock.account.findUnique.mockResolvedValueOnce(null);

    const route = await getRoute();
    const response = await route.POST(
      makeRequest("http://localhost/api/tickets/staff", {
        type: "ORDER",
        notes: "Test notes",
        createdByEmail: "missing@example.com",
        lines: [{ catalogItemId: 1, countDelta: 1 }],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe(
      "Unable to resolve a valid active account for ticket creator.",
    );
  });

  it("POST rejects non-staff creator role", async () => {
    mockAuthorizedSession();

    prismaMock.account.findUnique.mockResolvedValueOnce({
      id: 1,
      email: "user@example.com",
      displayName: "Normal User",
      role: "USER",
      status: "active",
      deletedAt: null,
    });

    const route = await getRoute();
    const response = await route.POST(
      makeRequest("http://localhost/api/tickets/staff", {
        type: "ORDER",
        notes: "Test notes",
        createdByEmail: "user@example.com",
        lines: [{ catalogItemId: 1, countDelta: 1 }],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(403);
    expect(body.error).toBe("Only staff accounts can create tickets.");
  });

  it("POST rejects missing catalog item", async () => {
    mockAuthorizedSession();

    prismaMock.account.findUnique.mockResolvedValueOnce({
      id: 1,
      email: "staff@example.com",
      displayName: "Staff User",
      role: "STAFF",
      status: "active",
      deletedAt: null,
    });

    prismaMock.catalogItem.findMany.mockResolvedValueOnce([]);

    const route = await getRoute();
    const response = await route.POST(
      makeRequest("http://localhost/api/tickets/staff", {
        type: "ORDER",
        notes: "Test notes",
        createdByEmail: "staff@example.com",
        lines: [{ catalogItemId: 999, countDelta: 1 }],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("Catalog item 999 does not exist.");
  });

  it("POST rejects order quantity greater than available stock", async () => {
    mockAuthorizedSession();

    prismaMock.account.findUnique.mockResolvedValueOnce({
      id: 1,
      email: "staff@example.com",
      displayName: "Staff User",
      role: "STAFF",
      status: "active",
      deletedAt: null,
    });

    prismaMock.catalogItem.findMany.mockResolvedValueOnce([
      {
        id: 5,
        itemName: "Gloves",
        quantityInStock: 2,
        reorderLevel: 1,
      },
    ]);

    const route = await getRoute();
    const response = await route.POST(
      makeRequest("http://localhost/api/tickets/staff", {
        type: "ORDER",
        notes: "Test notes",
        createdByEmail: "staff@example.com",
        lines: [{ catalogItemId: 5, countDelta: 10 }],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe(
      `"Gloves" only has 2 in stock, but 10 was requested.`,
    );
  });

  it("POST returns 500 when unexpected transaction error occurs", async () => {
    mockAuthorizedSession();

    prismaMock.account.findUnique.mockResolvedValueOnce({
      id: 1,
      email: "staff@example.com",
      displayName: "Staff User",
      role: "STAFF",
      status: "active",
      deletedAt: null,
    });

    prismaMock.catalogItem.findMany.mockResolvedValueOnce([
      {
        id: 5,
        itemName: "Gloves",
        quantityInStock: 10,
        reorderLevel: 3,
      },
    ]);

    prismaMock.$transaction.mockRejectedValueOnce(new Error("Unexpected DB error"));

    const route = await getRoute();
    const response = await route.POST(
      makeRequest("http://localhost/api/tickets/staff", {
        type: "ORDER",
        notes: "Test notes",
        createdByEmail: "staff@example.com",
        lines: [{ catalogItemId: 5, countDelta: 1 }],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.error).toBe("Failed to create ticket.");
  });
});