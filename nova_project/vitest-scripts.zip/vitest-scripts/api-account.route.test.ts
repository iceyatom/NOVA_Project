import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";

const { mockPrisma, mockHashPassword, mockVerifyPassword } = vi.hoisted(() => {
  return {
    mockPrisma: {
      account: {
        findUnique: vi.fn(),
        update: vi.fn(),
      },
    },
    mockHashPassword: vi.fn(),
    mockVerifyPassword: vi.fn(),
  };
});

vi.mock("@/lib/db", () => ({
  prisma: mockPrisma,
}));

vi.mock("@/lib/auth/passwordHash", () => ({
  hashPassword: mockHashPassword,
  verifyPassword: mockVerifyPassword,
}));

import { GET, PATCH, DELETE } from "@/app/api/account/route";

function makeNextRequest(
  url: string,
  init?: {
    method?: string;
    body?: unknown;
    headers?: HeadersInit;
  },
) {
  return new NextRequest(url, {
    method: init?.method,
    body:
      typeof init?.body === "string"
        ? init.body
        : init?.body !== undefined
          ? JSON.stringify(init.body)
          : undefined,
    headers: {
      "content-type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
}

async function readJson(response: Response) {
  return response.json();
}

function expectNoCacheHeaders(response: Response) {
  expect(response.headers.get("cache-control")).toBe(
    "no-store, no-cache, must-revalidate, proxy-revalidate",
  );
  expect(response.headers.get("pragma")).toBe("no-cache");
  expect(response.headers.get("expires")).toBe("0");
}

describe("/api/account route", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("GET", () => {
    it("returns 400 when email is missing", async () => {
      const request = new NextRequest("http://localhost/api/account");

      const response = await GET(request);
      const body = await readJson(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error: "Email is required.",
      });
      expect(mockPrisma.account.findUnique).not.toHaveBeenCalled();
      expectNoCacheHeaders(response);
    });

    it("normalizes email, returns account data, and fills nullable fields with empty strings", async () => {
      const createdAt = new Date("2026-01-01T00:00:00.000Z");
      const updatedAt = new Date("2026-01-02T00:00:00.000Z");

      mockPrisma.account.findUnique.mockResolvedValueOnce({
        id: 123,
        email: "user@example.com",
        displayName: null,
        phone: null,
        role: "STAFF",
        status: "active",
        deletedAt: null,
        createdAt,
        updatedAt,
      });

      const request = new NextRequest(
        "http://localhost/api/account?email=%20USER@Example.com%20",
      );

      const response = await GET(request);
      const body = await readJson(response);

      expect(mockPrisma.account.findUnique).toHaveBeenCalledWith({
        where: { email: "user@example.com" },
        select: {
          id: true,
          email: true,
          displayName: true,
          phone: true,
          role: true,
          status: true,
          deletedAt: true,
          createdAt: true,
          updatedAt: true,
        },
      });

      expect(response.status).toBe(200);
      expect(body).toEqual({
        ok: true,
        account: {
          id: 123,
          email: "user@example.com",
          displayName: "",
          phone: "",
          role: "STAFF",
          status: "active",
          createdAt: createdAt.toISOString(),
          updatedAt: updatedAt.toISOString(),
        },
        sensitiveLock: {
          isLocked: false,
          remainingMs: 0,
          unlocksAt: null,
        },
      });
      expectNoCacheHeaders(response);
    });

    it("returns 404 when account is not found", async () => {
      mockPrisma.account.findUnique.mockResolvedValueOnce(null);

      const request = new NextRequest(
        "http://localhost/api/account?email=user@example.com",
      );

      const response = await GET(request);
      const body = await readJson(response);

      expect(response.status).toBe(404);
      expect(body).toEqual({
        ok: false,
        error: "Account not found.",
      });
      expectNoCacheHeaders(response);
    });

    it("returns 404 when account has been soft-deleted", async () => {
      mockPrisma.account.findUnique.mockResolvedValueOnce({
        id: 123,
        email: "user@example.com",
        displayName: "User",
        phone: "9165551234",
        role: "STAFF",
        status: "active",
        deletedAt: new Date("2026-01-03T00:00:00.000Z"),
        createdAt: new Date("2026-01-01T00:00:00.000Z"),
        updatedAt: new Date("2026-01-02T00:00:00.000Z"),
      });

      const request = new NextRequest(
        "http://localhost/api/account?email=user@example.com",
      );

      const response = await GET(request);
      const body = await readJson(response);

      expect(response.status).toBe(404);
      expect(body).toEqual({
        ok: false,
        error: "Account not found.",
      });
    });

    it("returns 500 when prisma throws", async () => {
      mockPrisma.account.findUnique.mockRejectedValueOnce(new Error("db exploded"));

      const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

      const request = new NextRequest(
        "http://localhost/api/account?email=user@example.com",
      );

      const response = await GET(request);
      const body = await readJson(response);

      expect(response.status).toBe(500);
      expect(body).toEqual({
        ok: false,
        error: "Unable to load account details.",
      });
      expect(errorSpy).toHaveBeenCalled();

      errorSpy.mockRestore();
    });
  });

  describe("PATCH", () => {
    it("returns 400 for invalid JSON", async () => {
      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: "{",
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error: "Invalid JSON body.",
      });
      expectNoCacheHeaders(response);
    });

    it("returns 400 when currentEmail is missing", async () => {
      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          displayName: "User",
          phone: "9165551234",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error: "Current email is required.",
      });
    });

    it("returns 400 when displayName is missing", async () => {
      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          phone: "9165551234",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error: "Display name is required.",
      });
    });

    it("returns 400 when phone is missing", async () => {
      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          displayName: "User",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error: "Phone number is required.",
      });
    });

    it("returns 400 when phone number is too short", async () => {
      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          displayName: "User",
          phone: "12345",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error: "Phone number is too short. Use exactly 10 digits.",
      });
    });

    it("returns 400 when phone number is too long", async () => {
      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          displayName: "User",
          phone: "1234567890123",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error: "Phone number is too long. Use exactly 10 digits.",
      });
    });

    it("returns 404 when account is not found", async () => {
      mockPrisma.account.findUnique.mockResolvedValueOnce(null);

      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          displayName: "Updated User",
          phone: "9165551234",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(response.status).toBe(404);
      expect(body).toEqual({
        ok: false,
        error: "Account not found.",
      });
    });

    it("returns 400 when newEmail is invalid", async () => {
      mockPrisma.account.findUnique.mockResolvedValueOnce({
        id: 1,
        email: "user@example.com",
        displayName: "User",
        phone: "9165551234",
        passwordHash: "hashed-password",
        deletedAt: null,
        status: "active",
      });

      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          displayName: "Updated User",
          phone: "9165551234",
          newEmail: "bad-email",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error: "Please enter a valid email address.",
      });
      expect(mockVerifyPassword).not.toHaveBeenCalled();
      expect(mockPrisma.account.update).not.toHaveBeenCalled();
    });

    it("returns 400 when newPassword is weak", async () => {
      mockPrisma.account.findUnique.mockResolvedValueOnce({
        id: 1,
        email: "user@example.com",
        displayName: "User",
        phone: "9165551234",
        passwordHash: "hashed-password",
        deletedAt: null,
        status: "active",
      });

      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          displayName: "Updated User",
          phone: "9165551234",
          newPassword: "weak",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error:
          "Password must be at least 8 characters and include uppercase, lowercase, and a number.",
      });
      expect(mockVerifyPassword).not.toHaveBeenCalled();
      expect(mockPrisma.account.update).not.toHaveBeenCalled();
    });

    it("returns 400 when sensitive change is requested without currentPassword", async () => {
      mockPrisma.account.findUnique.mockResolvedValueOnce({
        id: 1,
        email: "user@example.com",
        displayName: "User",
        phone: "9165551234",
        passwordHash: "hashed-password",
        deletedAt: null,
        status: "active",
      });

      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          displayName: "Updated User",
          phone: "9165551234",
          newEmail: "new@example.com",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error: "Current password is required to change email or password.",
      });
      expect(mockVerifyPassword).not.toHaveBeenCalled();
      expect(mockPrisma.account.update).not.toHaveBeenCalled();
    });

    it("returns 401 when currentPassword is incorrect", async () => {
      mockPrisma.account.findUnique.mockResolvedValueOnce({
        id: 1,
        email: "user@example.com",
        displayName: "User",
        phone: "9165551234",
        passwordHash: "hashed-password",
        deletedAt: null,
        status: "active",
      });
      mockVerifyPassword.mockResolvedValueOnce(false);

      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          displayName: "Updated User",
          phone: "9165551234",
          newEmail: "new@example.com",
          currentPassword: "wrong-password",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(mockVerifyPassword).toHaveBeenCalledWith(
        "wrong-password",
        "hashed-password",
      );
      expect(response.status).toBe(401);
      expect(body).toEqual({
        ok: false,
        error: "Current password is incorrect.",
      });
      expect(mockPrisma.account.update).not.toHaveBeenCalled();
    });

    it("returns 409 when newEmail already belongs to another account", async () => {
      mockPrisma.account.findUnique
        .mockResolvedValueOnce({
          id: 1,
          email: "user@example.com",
          displayName: "User",
          phone: "9165551234",
          passwordHash: "hashed-password",
          deletedAt: null,
          status: "active",
        })
        .mockResolvedValueOnce({
          id: 999,
        });

      mockVerifyPassword.mockResolvedValueOnce(true);

      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          displayName: "Updated User",
          phone: "9165551234",
          newEmail: "taken@example.com",
          currentPassword: "CorrectPass1",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(response.status).toBe(409);
      expect(body).toEqual({
        ok: false,
        error: "An account with that email already exists.",
      });
      expect(mockPrisma.account.update).not.toHaveBeenCalled();
    });

    it("updates only non-sensitive fields without password verification", async () => {
      const createdAt = new Date("2026-01-01T00:00:00.000Z");
      const updatedAt = new Date("2026-01-04T00:00:00.000Z");

      mockPrisma.account.findUnique.mockResolvedValueOnce({
        id: 1,
        email: "user@example.com",
        displayName: "Old Name",
        phone: "9165550000",
        passwordHash: "hashed-password",
        deletedAt: null,
        status: "active",
      });

      mockPrisma.account.update.mockResolvedValueOnce({
        id: 1,
        email: "user@example.com",
        displayName: "New Name",
        phone: "9165551234",
        role: "STAFF",
        status: "active",
        createdAt,
        updatedAt,
      });

      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          displayName: "New Name",
          phone: "9165551234",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(mockVerifyPassword).not.toHaveBeenCalled();
      expect(mockHashPassword).not.toHaveBeenCalled();

      expect(mockPrisma.account.update).toHaveBeenCalledWith({
        where: { id: 1 },
        data: {
          displayName: "New Name",
          phone: "9165551234",
        },
        select: {
          id: true,
          email: true,
          displayName: true,
          phone: true,
          role: true,
          status: true,
          createdAt: true,
          updatedAt: true,
        },
      });

      expect(response.status).toBe(200);
      expect(body).toEqual({
        ok: true,
        message: "Account updated successfully.",
        account: {
          id: 1,
          email: "user@example.com",
          displayName: "New Name",
          phone: "9165551234",
          role: "STAFF",
          status: "active",
          createdAt: createdAt.toISOString(),
          updatedAt: updatedAt.toISOString(),
        },
        sensitiveLock: {
          isLocked: false,
          remainingMs: 0,
          unlocksAt: null,
        },
      });
      expectNoCacheHeaders(response);
    });

    it("updates email and password after verifying currentPassword", async () => {
      const createdAt = new Date("2026-01-01T00:00:00.000Z");
      const updatedAt = new Date("2026-01-05T00:00:00.000Z");

      mockPrisma.account.findUnique
        .mockResolvedValueOnce({
          id: 1,
          email: "user@example.com",
          displayName: "Old Name",
          phone: "9165550000",
          passwordHash: "old-hash",
          deletedAt: null,
          status: "active",
        })
        .mockResolvedValueOnce(null);

      mockVerifyPassword.mockResolvedValueOnce(true);
      mockHashPassword.mockResolvedValueOnce("new-hash");

      mockPrisma.account.update.mockResolvedValueOnce({
        id: 1,
        email: "new@example.com",
        displayName: "Updated Name",
        phone: "9165551234",
        role: "STAFF",
        status: "active",
        createdAt,
        updatedAt,
      });

      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          displayName: "Updated Name",
          phone: "9165551234",
          newEmail: "new@example.com",
          currentPassword: "CorrectPass1",
          newPassword: "NewPassword1",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(mockVerifyPassword).toHaveBeenCalledWith(
        "CorrectPass1",
        "old-hash",
      );
      expect(mockHashPassword).toHaveBeenCalledWith("NewPassword1");

      expect(mockPrisma.account.update).toHaveBeenCalledWith({
        where: { id: 1 },
        data: {
          displayName: "Updated Name",
          phone: "9165551234",
          email: "new@example.com",
          passwordHash: "new-hash",
        },
        select: {
          id: true,
          email: true,
          displayName: true,
          phone: true,
          role: true,
          status: true,
          createdAt: true,
          updatedAt: true,
        },
      });

      expect(response.status).toBe(200);
      expect(body).toEqual({
        ok: true,
        message: "Account updated successfully.",
        account: {
          id: 1,
          email: "new@example.com",
          displayName: "Updated Name",
          phone: "9165551234",
          role: "STAFF",
          status: "active",
          createdAt: createdAt.toISOString(),
          updatedAt: updatedAt.toISOString(),
        },
        sensitiveLock: {
          isLocked: false,
          remainingMs: 0,
          unlocksAt: null,
        },
      });
    });

    it("returns 500 when prisma throws during update", async () => {
      mockPrisma.account.findUnique.mockRejectedValueOnce(new Error("db down"));

      const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

      const request = makeNextRequest("http://localhost/api/account", {
        method: "PATCH",
        body: {
          currentEmail: "user@example.com",
          displayName: "Updated Name",
          phone: "9165551234",
        },
      });

      const response = await PATCH(request);
      const body = await readJson(response);

      expect(response.status).toBe(500);
      expect(body).toEqual({
        ok: false,
        error: "Unable to update account.",
      });
      expect(errorSpy).toHaveBeenCalled();

      errorSpy.mockRestore();
    });
  });

  describe("DELETE", () => {
    it("returns 400 for invalid JSON", async () => {
      const request = makeNextRequest("http://localhost/api/account", {
        method: "DELETE",
        body: "{",
      });

      const response = await DELETE(request);
      const body = await readJson(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error: "Invalid JSON body.",
      });
    });

    it("returns 400 when email or password is missing", async () => {
      const request = makeNextRequest("http://localhost/api/account", {
        method: "DELETE",
        body: {
          currentEmail: "user@example.com",
        },
      });

      const response = await DELETE(request);
      const body = await readJson(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error: "Email and password are required.",
      });
    });

    it("returns 404 when account is not found", async () => {
      mockPrisma.account.findUnique.mockResolvedValueOnce(null);

      const request = makeNextRequest("http://localhost/api/account", {
        method: "DELETE",
        body: {
          currentEmail: "user@example.com",
          password: "CorrectPass1",
        },
      });

      const response = await DELETE(request);
      const body = await readJson(response);

      expect(response.status).toBe(404);
      expect(body).toEqual({
        ok: false,
        error: "Account not found.",
      });
    });

    it("returns 401 when password confirmation fails", async () => {
      mockPrisma.account.findUnique.mockResolvedValueOnce({
        id: 1,
        passwordHash: "stored-hash",
        deletedAt: null,
      });

      mockVerifyPassword.mockResolvedValueOnce(false);

      const request = makeNextRequest("http://localhost/api/account", {
        method: "DELETE",
        body: {
          currentEmail: "user@example.com",
          password: "WrongPass1",
        },
      });

      const response = await DELETE(request);
      const body = await readJson(response);

      expect(mockVerifyPassword).toHaveBeenCalledWith(
        "WrongPass1",
        "stored-hash",
      );
      expect(response.status).toBe(401);
      expect(body).toEqual({
        ok: false,
        error: "Password confirmation failed.",
      });
      expect(mockPrisma.account.update).not.toHaveBeenCalled();
    });

    it("soft-deletes the account when password confirmation succeeds", async () => {
      mockPrisma.account.findUnique.mockResolvedValueOnce({
        id: 1,
        passwordHash: "stored-hash",
        deletedAt: null,
      });

      mockVerifyPassword.mockResolvedValueOnce(true);
      mockPrisma.account.update.mockResolvedValueOnce({});

      const request = makeNextRequest("http://localhost/api/account", {
        method: "DELETE",
        body: {
          currentEmail: " USER@Example.com ",
          password: "CorrectPass1",
        },
      });

      const response = await DELETE(request);
      const body = await readJson(response);

      expect(mockPrisma.account.findUnique).toHaveBeenCalledWith({
        where: { email: "user@example.com" },
        select: {
          id: true,
          passwordHash: true,
          deletedAt: true,
        },
      });

      expect(mockPrisma.account.update).toHaveBeenCalledWith({
        where: { id: 1 },
        data: {
          status: "deleted",
          deletedAt: expect.any(Date),
        },
      });

      expect(response.status).toBe(200);
      expect(body).toEqual({
        ok: true,
        message: "Account deleted successfully.",
      });
      expectNoCacheHeaders(response);
    });

    it("returns 500 when prisma throws during delete", async () => {
      mockPrisma.account.findUnique.mockRejectedValueOnce(new Error("db down"));

      const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

      const request = makeNextRequest("http://localhost/api/account", {
        method: "DELETE",
        body: {
          currentEmail: "user@example.com",
          password: "CorrectPass1",
        },
      });

      const response = await DELETE(request);
      const body = await readJson(response);

      expect(response.status).toBe(500);
      expect(body).toEqual({
        ok: false,
        error: "Unable to delete account.",
      });
      expect(errorSpy).toHaveBeenCalled();

      errorSpy.mockRestore();
    });
  });
});