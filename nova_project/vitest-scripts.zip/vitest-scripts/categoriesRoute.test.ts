import { NextRequest, NextResponse } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const { mockPrisma, mockRequireStaffSession } = vi.hoisted(() => ({
  mockRequireStaffSession: vi.fn(),
  mockPrisma: {
    category3: {
      findMany: vi.fn(),
      findUnique: vi.fn(),
      create: vi.fn(),
      update: vi.fn(),
      delete: vi.fn(),
    },
    category2: {
      findFirst: vi.fn(),
      count: vi.fn(),
      create: vi.fn(),
      update: vi.fn(),
      delete: vi.fn(),
    },
    category1: {
      findFirst: vi.fn(),
      count: vi.fn(),
      create: vi.fn(),
      update: vi.fn(),
      delete: vi.fn(),
    },
  },
}));

vi.mock("@/lib/db", () => ({
  prisma: mockPrisma,
}));

vi.mock("@/lib/auth/staffAccess", () => ({
  requireStaffSession: (...args: unknown[]) => mockRequireStaffSession(...args),
}));

import {
  DELETE,
  GET,
  PATCH,
  POST,
} from "../src/app/api/catalog/staff/categories/route";

function makeRequest(url: string, init?: RequestInit) {
  return new NextRequest(url, init);
}

describe("category management API route", () => {
  beforeEach(() => {
    vi.resetAllMocks();
    mockRequireStaffSession.mockResolvedValue({
      ok: true,
      account: { id: 1, role: "ADMIN" },
    });
  });

  // Verifies auth failures are passed through unchanged.
  it("passes through unauthorized response", async () => {
    mockRequireStaffSession.mockResolvedValue({
      ok: false,
      response: NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 }),
    });

    const response = await GET(
      makeRequest("http://localhost/api/catalog/staff/categories?action=hierarchy"),
    );

    expect(response.status).toBe(401);
  });

  // Verifies GET hierarchy flattens categories, subcategories, and types.
  it("returns hierarchy payload", async () => {
    mockPrisma.category3.findMany.mockResolvedValue([
      {
        name: "Laboratory Supplies",
        category2s: [
          {
            name: "Containers",
            category1s: [{ name: "Beakers" }],
          },
        ],
      },
    ]);

    const response = await GET(
      makeRequest("http://localhost/api/catalog/staff/categories?action=hierarchy"),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toMatchObject({
      success: true,
      data: {
        categories: ["Laboratory Supplies"],
        subcategories: [
          { name: "Containers", parentCategory3: "Laboratory Supplies" },
        ],
        types: [
          {
            name: "Beakers",
            parentCategory3: "Laboratory Supplies",
            parentCategory2: "Containers",
          },
        ],
      },
    });
  });

  // Verifies GET only supports hierarchy or dependencies actions.
  it("returns 405 for unsupported GET action", async () => {
    const response = await GET(
      makeRequest("http://localhost/api/catalog/staff/categories?action=list"),
    );
    const body = await response.json();

    expect(response.status).toBe(405);
    expect(body.error).toBe("Unsupported GET request.");
  });

  // Verifies category2 dependency checks require parentCategory3.
  it("returns 400 for category2 dependencies without parent category", async () => {
    const response = await GET(
      makeRequest(
        "http://localhost/api/catalog/staff/categories?action=dependencies&level=category2&name=Microscope",
      ),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("Parent Category is required.");
  });

  // Verifies level-3 dependency lookup returns subcategory/type counts.
  it("returns category3 dependency counts", async () => {
    mockPrisma.category3.findUnique.mockResolvedValue({ id: 7 });
    mockPrisma.category2.count.mockResolvedValue(3);
    mockPrisma.category1.count.mockResolvedValue(9);

    const response = await GET(
      makeRequest(
        "http://localhost/api/catalog/staff/categories?action=dependencies&level=category3&name=Laboratory%20Supplies",
      ),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toMatchObject({
      success: true,
      data: {
        level: "category3",
        subcategoryCount: 3,
        typeCount: 9,
      },
    });
  });

  // Verifies duplicate category3 creation returns HTTP 409.
  it("returns 409 when creating duplicate category3", async () => {
    mockPrisma.category3.findUnique.mockResolvedValue({ id: 1 });

    const response = await POST(
      makeRequest("http://localhost/api/catalog/staff/categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          level: "category3",
          name: "Laboratory Supplies",
        }),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(409);
    expect(body.error).toBe("Category already exists.");
  });

  // Verifies creating category2 works when parent category is valid.
  it("creates category2 under a valid parent category", async () => {
    mockPrisma.category3.findUnique.mockResolvedValue({
      id: 10,
      name: "Laboratory Supplies",
    });
    mockPrisma.category2.findFirst.mockResolvedValue(null);
    mockPrisma.category2.create.mockResolvedValue({
      id: 20,
      name: "Microscopy Supplies",
    });

    const response = await POST(
      makeRequest("http://localhost/api/catalog/staff/categories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          level: "category2",
          name: "Microscopy Supplies",
          parentCategory3: "Laboratory Supplies",
        }),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(201);
    expect(body).toMatchObject({
      success: true,
      data: {
        level: "category2",
        id: 20,
        name: "Microscopy Supplies",
        parentCategory3: "Laboratory Supplies",
      },
    });
  });

  // Verifies PATCH for category1 rejects unknown target parent path.
  it("returns 404 when moving category1 to a non-existent target parent", async () => {
    mockPrisma.category1.findFirst.mockResolvedValue({
      id: 30,
      name: "Slides",
      category2: {
        id: 11,
        name: "Microscopy Supplies",
        category3: { id: 10, name: "Laboratory Supplies" },
      },
    });
    mockPrisma.category2.findFirst.mockResolvedValue(null);

    const response = await PATCH(
      makeRequest("http://localhost/api/catalog/staff/categories", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          level: "category1",
          currentName: "Slides",
          newName: "Prepared Slides",
          currentParentCategory3: "Laboratory Supplies",
          currentParentCategory2: "Microscopy Supplies",
          newParentCategory3: "Live Plant Specimens",
          newParentCategory2: "Mosses",
        }),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(404);
    expect(body.error).toBe(
      "Target Parent Subcategory not found under selected Parent Category.",
    );
  });

  // Verifies Prisma unique conflicts during PATCH map to 409.
  it("returns 409 on PATCH when a uniqueness conflict occurs", async () => {
    mockPrisma.category3.findUnique
      .mockResolvedValueOnce({ id: 1, name: "A" })
      .mockResolvedValueOnce({ id: 2, name: "B" });
    mockPrisma.category2.findFirst.mockResolvedValue({ id: 5, name: "Tools" });
    mockPrisma.category2.update.mockRejectedValue({ code: "P2002" });

    const response = await PATCH(
      makeRequest("http://localhost/api/catalog/staff/categories", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          level: "category2",
          currentName: "Tools",
          newName: "Common Tools",
          currentParentCategory3: "A",
          newParentCategory3: "B",
        }),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(409);
    expect(body.error).toBe(
      "A category with this name already exists under the selected parent.",
    );
  });

  // Verifies deleting category3 returns cascade impact counts.
  it("deletes category3 and returns dependency totals", async () => {
    mockPrisma.category3.findUnique.mockResolvedValue({
      id: 44,
      name: "Microbiology",
    });
    mockPrisma.category2.count.mockResolvedValue(2);
    mockPrisma.category1.count.mockResolvedValue(6);
    mockPrisma.category3.delete.mockResolvedValue({ id: 44 });

    const response = await DELETE(
      makeRequest("http://localhost/api/catalog/staff/categories", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          level: "category3",
          name: "Microbiology",
        }),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toMatchObject({
      success: true,
      data: {
        level: "category3",
        name: "Microbiology",
        subcategoryCount: 2,
        typeCount: 6,
      },
    });
  });

  // Verifies category1 delete requires both parent category fields.
  it("returns 400 for category1 deletion without required parents", async () => {
    const response = await DELETE(
      makeRequest("http://localhost/api/catalog/staff/categories", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          level: "category1",
          name: "Prepared Slides",
        }),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe(
      "Parent Category and Parent Subcategory are required.",
    );
  });
});
