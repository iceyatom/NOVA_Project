import { NextRequest, NextResponse } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const { mockPrisma, mockRequireStaffSession, txMock } = vi.hoisted(() => {
  const tx = {
    alert: {
      findFirst: vi.fn(),
      update: vi.fn(),
      delete: vi.fn(),
    },
  };

  return {
    txMock: tx,
    mockRequireStaffSession: vi.fn(),
    mockPrisma: {
      alert: {
        count: vi.fn(),
        findMany: vi.fn(),
        create: vi.fn(),
      },
      account: {
        findMany: vi.fn(),
      },
      $transaction: vi.fn(),
    },
  };
});

vi.mock("@/lib/db", () => ({
  prisma: mockPrisma,
}));

vi.mock("@/lib/auth/staffAccess", () => ({
  requireStaffSession: (...args: unknown[]) => mockRequireStaffSession(...args),
}));

import { DELETE, GET, POST } from "../src/app/api/alerts/staff/route";

function makeGetRequest(url: string) {
  return new NextRequest(url, { method: "GET" });
}

function makeJsonRequest(url: string, method: "POST" | "DELETE", body: unknown) {
  return new NextRequest(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("alerts staff API route", () => {
  beforeEach(() => {
    vi.resetAllMocks();

    mockRequireStaffSession.mockResolvedValue({
      ok: true,
      account: { id: 42, role: "STAFF" },
    });

    mockPrisma.$transaction.mockImplementation(async (cb: (tx: typeof txMock) => Promise<unknown>) =>
      cb(txMock),
    );
  });

  // Verifies GET returns auth response unchanged when no staff session is available.
  it("passes through unauthorized response for GET", async () => {
    mockRequireStaffSession.mockResolvedValue({
      ok: false,
      response: NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 }),
    });

    const response = await GET(makeGetRequest("http://localhost/api/alerts/staff"));
    expect(response.status).toBe(401);
  });

  // Verifies GET enforces default limit and maps alert creation time to ISO strings.
  it("returns mapped alerts with default limit when limit is invalid", async () => {
    const createdAt = new Date("2026-01-01T12:00:00.000Z");
    mockPrisma.alert.count.mockResolvedValue(1);
    mockPrisma.alert.findMany.mockResolvedValue([
      {
        id: 100,
        title: "System Message",
        description: "Inventory threshold reached",
        type: "ANNOUNCEMENT",
        creationTime: createdAt,
      },
    ]);

    const response = await GET(
      makeGetRequest("http://localhost/api/alerts/staff?limit=invalid"),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toMatchObject({
      success: true,
      count: 1,
      alerts: [
        {
          id: 100,
          title: "System Message",
          description: "Inventory threshold reached",
          type: "ANNOUNCEMENT",
          creationTime: "2026-01-01T12:00:00.000Z",
        },
      ],
    });
    expect(mockPrisma.alert.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        take: 5,
      }),
    );
    expect(response.headers.get("cache-control")).toContain("no-store");
  });

  // Verifies GET caps limit at max allowed value.
  it("caps GET limit at 20 when requested limit is too large", async () => {
    mockPrisma.alert.count.mockResolvedValue(0);
    mockPrisma.alert.findMany.mockResolvedValue([]);

    const response = await GET(
      makeGetRequest("http://localhost/api/alerts/staff?limit=999"),
    );

    expect(response.status).toBe(200);
    expect(mockPrisma.alert.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        take: 20,
      }),
    );
  });

  // Verifies POST rejects missing titles.
  it("returns 400 when POST title is missing", async () => {
    mockRequireStaffSession.mockResolvedValue({
      ok: true,
      account: { id: 1, role: "ADMIN" },
    });

    const response = await POST(
      makeJsonRequest("http://localhost/api/alerts/staff", "POST", {
        description: "Hello",
        sendToAdmin: true,
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("Announcement title is required.");
  });

  // Verifies POST requires at least one recipient type.
  it("returns 400 when POST has no recipient audience", async () => {
    mockRequireStaffSession.mockResolvedValue({
      ok: true,
      account: { id: 1, role: "ADMIN" },
    });

    const response = await POST(
      makeJsonRequest("http://localhost/api/alerts/staff", "POST", {
        title: "Reminder",
        description: "Check dashboard",
        sendToAdmin: false,
        sendToStaff: false,
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("Select at least one recipient type.");
  });

  // Verifies POST returns 404 when no matching recipients are found.
  it("returns 404 when POST recipient lookup returns no accounts", async () => {
    mockRequireStaffSession.mockResolvedValue({
      ok: true,
      account: { id: 1, role: "ADMIN" },
    });
    mockPrisma.account.findMany.mockResolvedValue([]);

    const response = await POST(
      makeJsonRequest("http://localhost/api/alerts/staff", "POST", {
        title: "Reminder",
        description: "Check dashboard",
        sendToAdmin: true,
        sendToStaff: true,
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(404);
    expect(body.error).toBe("No recipient accounts found for the selected audience.");
  });

  // Verifies POST creates an announcement and returns recipient stats.
  it("creates an alert successfully for selected audiences", async () => {
    mockRequireStaffSession.mockResolvedValue({
      ok: true,
      account: { id: 1, role: "ADMIN" },
    });
    mockPrisma.account.findMany.mockResolvedValue([{ id: 10 }, { id: 11 }]);
    mockPrisma.alert.create.mockResolvedValue({ id: 777 });

    const response = await POST(
      makeJsonRequest("http://localhost/api/alerts/staff", "POST", {
        title: "New Policy",
        description: "Please review policy updates.",
        sendToAdmin: true,
        sendToStaff: true,
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(201);
    expect(body).toMatchObject({
      success: true,
      alertId: 777,
      recipientCount: 2,
    });
    expect(mockPrisma.account.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: expect.objectContaining({
          role: { in: ["ADMIN", "STAFF"] },
        }),
      }),
    );
  });

  // Verifies DELETE rejects malformed JSON payloads.
  it("returns 400 for invalid DELETE JSON body", async () => {
    const request = new NextRequest("http://localhost/api/alerts/staff", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: "{bad-json",
    });

    const response = await DELETE(request);
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("Invalid JSON body.");
  });

  // Verifies DELETE validates alertId.
  it("returns 400 for missing or invalid alertId", async () => {
    const response = await DELETE(
      makeJsonRequest("http://localhost/api/alerts/staff", "DELETE", {
        alertId: 0,
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("A valid alertId is required.");
  });

  // Verifies DELETE returns 404 when alert is not associated with the current account.
  it("returns 404 when DELETE alert is not found for account", async () => {
    txMock.alert.findFirst.mockResolvedValue(null);

    const response = await DELETE(
      makeJsonRequest("http://localhost/api/alerts/staff", "DELETE", {
        alertId: 55,
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(404);
    expect(body.error).toBe("Alert was not found.");
  });

  // Verifies DELETE disconnects the account and keeps alert when other recipients remain.
  it("dismisses alert without deleting it when recipients remain", async () => {
    txMock.alert.findFirst.mockResolvedValue({ id: 55 });
    txMock.alert.update.mockResolvedValue({ id: 55, _count: { accounts: 2 } });

    const response = await DELETE(
      makeJsonRequest("http://localhost/api/alerts/staff", "DELETE", {
        alertId: "55",
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toMatchObject({
      success: true,
      alertId: 55,
      deletedAlert: false,
    });
    expect(txMock.alert.delete).not.toHaveBeenCalled();
  });

  // Verifies DELETE removes the alert record after last recipient is dismissed.
  it("dismisses and deletes alert when no recipients remain", async () => {
    txMock.alert.findFirst.mockResolvedValue({ id: 12 });
    txMock.alert.update.mockResolvedValue({ id: 12, _count: { accounts: 0 } });
    txMock.alert.delete.mockResolvedValue({ id: 12 });

    const response = await DELETE(
      makeJsonRequest("http://localhost/api/alerts/staff", "DELETE", {
        alertId: 12,
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toMatchObject({
      success: true,
      alertId: 12,
      deletedAlert: true,
    });
    expect(txMock.alert.delete).toHaveBeenCalledWith({
      where: { id: 12 },
      select: { id: true },
    });
  });
});
