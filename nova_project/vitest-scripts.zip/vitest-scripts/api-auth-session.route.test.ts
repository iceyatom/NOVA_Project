import { describe, it, expect, vi, beforeEach } from "vitest";
import { GET } from "@/app/api/auth/session/route";

// Mocks

vi.mock("next/headers", () => ({
  cookies: vi.fn(),
}));

vi.mock("@/lib/db", () => ({
  prisma: {
    session: {
      findUnique: vi.fn(),
    },
  },
}));

import { cookies } from "next/headers";
import { prisma } from "@/lib/db";

// Helpers

function mockCookies(token: string | undefined) {
  vi.mocked(cookies).mockResolvedValue({
    get: (name: string) =>
      name === "session" && token ? { name, value: token } : undefined,
  } as never);
}

// Fixtures

const mockAccount = {
  id: 1,
  email: "user@example.com",
  displayName: "Test User",
  role: "employee",
  status: "active",
  deletedAt: null,
};

const mockSession = {
  token: "valid-token-abc123",
  expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
  account: mockAccount,
};

// Tests

describe("GET /api/auth/session", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  // Invalid inputs

  describe("invalid inputs", () => {
    it("returns 401 when no session cookie is present", async () => {
      mockCookies(undefined);
      const res = await GET();
      expect(res.status).toBe(401);
      const body = await res.json();
      expect(body.ok).toBe(false);
    });

    it("returns 401 when session token does not exist in the database", async () => {
      mockCookies("nonexistent-token");
      vi.mocked(prisma.session.findUnique).mockResolvedValue(null);
      const res = await GET();
      expect(res.status).toBe(401);
      const body = await res.json();
      expect(body.ok).toBe(false);
    });

    it("returns 401 when session is expired", async () => {
      mockCookies("expired-token");
      vi.mocked(prisma.session.findUnique).mockResolvedValue({
        ...mockSession,
        expiresAt: new Date(Date.now() - 1000), // 1 second in the past
      } as never);
      const res = await GET();
      expect(res.status).toBe(401);
      const body = await res.json();
      expect(body.ok).toBe(false);
    });

    it("returns 401 when account is soft-deleted", async () => {
      mockCookies("valid-token-abc123");
      vi.mocked(prisma.session.findUnique).mockResolvedValue({
        ...mockSession,
        account: { ...mockAccount, deletedAt: new Date() },
      } as never);
      const res = await GET();
      expect(res.status).toBe(401);
      const body = await res.json();
      expect(body.ok).toBe(false);
    });

    it("returns 401 when account status is not 'active'", async () => {
      mockCookies("valid-token-abc123");
      vi.mocked(prisma.session.findUnique).mockResolvedValue({
        ...mockSession,
        account: { ...mockAccount, status: "suspended" },
      } as never);
      const res = await GET();
      expect(res.status).toBe(401);
      const body = await res.json();
      expect(body.ok).toBe(false);
    });

    it("returns 401 when session has no associated account", async () => {
      mockCookies("valid-token-abc123");
      vi.mocked(prisma.session.findUnique).mockResolvedValue({
        ...mockSession,
        account: null,
      } as never);
      const res = await GET();
      expect(res.status).toBe(401);
      const body = await res.json();
      expect(body.ok).toBe(false);
    });

    it("returns 500 when database throws on session lookup", async () => {
      mockCookies("valid-token-abc123");
      vi.mocked(prisma.session.findUnique).mockRejectedValue(
        new Error("DB connection lost"),
      );
      const res = await GET();
      expect(res.status).toBe(500);
      const body = await res.json();
      expect(body.ok).toBe(false);
    });
  });

  // Valid inputs

  describe("valid inputs", () => {
    it("returns 200 with account data for a valid, non-expired session", async () => {
      mockCookies("valid-token-abc123");
      vi.mocked(prisma.session.findUnique).mockResolvedValue(
        mockSession as never,
      );
      const res = await GET();
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.ok).toBe(true);
      expect(body.account).toMatchObject({
        id: mockAccount.id,
        email: mockAccount.email,
        displayName: mockAccount.displayName,
        role: mockAccount.role,
      });
    });

    it("does not expose deletedAt, status, or passwordHash in the response", async () => {
      mockCookies("valid-token-abc123");
      vi.mocked(prisma.session.findUnique).mockResolvedValue(
        mockSession as never,
      );
      const res = await GET();
      const body = await res.json();
      const serialized = JSON.stringify(body);
      expect(serialized).not.toContain("deletedAt");
      expect(serialized).not.toContain("status");
      expect(serialized).not.toContain("passwordHash");
    });

    it("looks up the session by the exact cookie token value", async () => {
      mockCookies("my-specific-token");
      vi.mocked(prisma.session.findUnique).mockResolvedValue(
        mockSession as never,
      );
      await GET();
      expect(prisma.session.findUnique).toHaveBeenCalledWith(
        expect.objectContaining({ where: { token: "my-specific-token" } }),
      );
    });

    it("returns 200 for a session expiring exactly in the future", async () => {
      mockCookies("valid-token-abc123");
      vi.mocked(prisma.session.findUnique).mockResolvedValue({
        ...mockSession,
        expiresAt: new Date(Date.now() + 1000), // 1 second from now
      } as never);
      const res = await GET();
      expect(res.status).toBe(200);
    });
  });
});
