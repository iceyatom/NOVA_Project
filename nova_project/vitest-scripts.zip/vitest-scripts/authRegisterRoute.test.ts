import { beforeEach, describe, expect, it, vi } from "vitest";

const { prismaMock, hashPasswordMock } = vi.hoisted(() => {
  return {
    prismaMock: {
      account: {
        findUnique: vi.fn(),
        create: vi.fn(),
      },
    },
    hashPasswordMock: vi.fn(),
  };
});

vi.mock("@/lib/db", () => ({
  prisma: prismaMock,
}));

vi.mock("@/lib/auth/passwordHash", () => ({
  hashPassword: hashPasswordMock,
}));

import { POST } from "@/app/api/auth/register/route"; // adjust if needed

function makeRequest(body?: unknown) {
  return new Request("http://localhost/api/create_account", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}

async function jsonOf(response: Response) {
  return response.json();
}

describe("create account API - system validation expectations", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("valid cases", () => {
    it("creates an account with valid input", async () => {
      prismaMock.account.findUnique.mockResolvedValue(null);
      hashPasswordMock.mockResolvedValue("hashed-password");
      prismaMock.account.create.mockResolvedValue({
        email: "user@example.com",
        displayName: "John Doe",
      });

      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password123",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      const body = await jsonOf(response);

      expect(response.status).toBe(200);
      expect(body).toEqual({
        ok: true,
        account: {
          email: "user@example.com",
          displayName: "John Doe",
        },
      });

      expect(prismaMock.account.findUnique).toHaveBeenCalledWith({
        where: { email: "user@example.com" },
      });

      expect(hashPasswordMock).toHaveBeenCalledWith("Password123");

      expect(prismaMock.account.create).toHaveBeenCalledWith({
        data: {
          email: "user@example.com",
          passwordHash: "hashed-password",
          displayName: "John Doe",
          phone: "1234567890",
          role: "STAFF",
        },
      });
    });

    it("normalizes email before checking uniqueness and saving", async () => {
      prismaMock.account.findUnique.mockResolvedValue(null);
      hashPasswordMock.mockResolvedValue("hashed-password");
      prismaMock.account.create.mockResolvedValue({
        email: "user@example.com",
        displayName: "John Doe",
      });

      const response = await POST(
        makeRequest({
          email: "  USER@Example.COM  ",
          password: "Password123",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      expect(response.status).toBe(200);
      expect(prismaMock.account.findUnique).toHaveBeenCalledWith({
        where: { email: "user@example.com" },
      });
      expect(prismaMock.account.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          email: "user@example.com",
        }),
      });
    });

    it("trims displayName and phone before saving", async () => {
      prismaMock.account.findUnique.mockResolvedValue(null);
      hashPasswordMock.mockResolvedValue("hashed-password");
      prismaMock.account.create.mockResolvedValue({
        email: "user@example.com",
        displayName: "Jane Doe",
      });

      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password123",
          displayName: "  Jane Doe  ",
          phone: "  1234567890  ",
        }),
      );

      expect(response.status).toBe(200);
      expect(prismaMock.account.create).toHaveBeenCalledWith({
        data: {
          email: "user@example.com",
          passwordHash: "hashed-password",
          displayName: "Jane Doe",
          phone: "1234567890",
          role: "STAFF",
        },
      });
    });
  });

  describe("invalid cases - required fields", () => {
    it("returns 400 for invalid JSON body", async () => {
      const request = new Request("http://localhost/api/create_account", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: "{bad-json",
      });

      const response = await POST(request);
      const body = await jsonOf(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        ok: false,
        error: "Invalid JSON body.",
      });
    });

    it("returns 400 when email is missing", async () => {
      const response = await POST(
        makeRequest({
          password: "Password123",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when password is missing", async () => {
      const response = await POST(
        makeRequest({
          email: "user@example.com",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when displayName is missing", async () => {
      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password123",
          phone: "1234567890",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when phone is missing", async () => {
      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password123",
          displayName: "John Doe",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when email is blank after trimming", async () => {
      const response = await POST(
        makeRequest({
          email: "   ",
          password: "Password123",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when displayName is blank after trimming", async () => {
      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password123",
          displayName: "   ",
          phone: "1234567890",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when phone is blank after trimming", async () => {
      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password123",
          displayName: "John Doe",
          phone: "   ",
        }),
      );

      expect(response.status).toBe(400);
    });
  });

  describe("invalid cases - frontend protections expected at backend", () => {
    it("returns 400 when phone number is too short", async () => {
      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password123",
          displayName: "John Doe",
          phone: "12345",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when phone number is too long", async () => {
      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password123",
          displayName: "John Doe",
          phone: "123456789012",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when phone number includes leading 1 with 11 digits", async () => {
      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password123",
          displayName: "John Doe",
          phone: "11234567890",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when email format is invalid", async () => {
      const response = await POST(
        makeRequest({
          email: "not-an-email",
          password: "Password123",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when password is too weak", async () => {
      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "abc",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when password has no uppercase letter", async () => {
      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "password123",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when password has no lowercase letter", async () => {
      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "PASSWORD123",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      expect(response.status).toBe(400);
    });

    it("returns 400 when password has no number", async () => {
      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      expect(response.status).toBe(400);
    });
  });

  describe("invalid cases - duplicate and server errors", () => {
    it("returns 409 when an account with the email already exists", async () => {
      prismaMock.account.findUnique.mockResolvedValue({
        id: 1,
        email: "user@example.com",
      });

      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password123",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      const body = await jsonOf(response);

      expect(response.status).toBe(409);
      expect(body).toEqual({
        ok: false,
        error: "An account with that email already exists.",
      });

      expect(hashPasswordMock).not.toHaveBeenCalled();
      expect(prismaMock.account.create).not.toHaveBeenCalled();
    });

    it("returns 500 when password hashing fails", async () => {
      prismaMock.account.findUnique.mockResolvedValue(null);
      hashPasswordMock.mockRejectedValue(new Error("hash failed"));

      const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password123",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      const body = await jsonOf(response);

      expect(response.status).toBe(500);
      expect(body).toEqual({
        ok: false,
        error: "Unable to create account.",
      });

      errorSpy.mockRestore();
    });

    it("returns 500 when account creation fails", async () => {
      prismaMock.account.findUnique.mockResolvedValue(null);
      hashPasswordMock.mockResolvedValue("hashed-password");
      prismaMock.account.create.mockRejectedValue(new Error("db failed"));

      const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

      const response = await POST(
        makeRequest({
          email: "user@example.com",
          password: "Password123",
          displayName: "John Doe",
          phone: "1234567890",
        }),
      );

      const body = await jsonOf(response);

      expect(response.status).toBe(500);
      expect(body).toEqual({
        ok: false,
        error: "Unable to create account.",
      });

      errorSpy.mockRestore();
    });
  });
});