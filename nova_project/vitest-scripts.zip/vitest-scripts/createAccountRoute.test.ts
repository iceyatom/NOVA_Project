import { POST } from "../src/app/api/create_account/route";

// ── Mocks ──────────────────────────────────────────────────────────────────

const mockFindUnique = vi.fn();
const mockUpsert = vi.fn();

vi.mock("@/lib/prisma", () => ({
  prisma: {
    account: {
      findUnique: (...args: unknown[]) => mockFindUnique(...args),
    },
    pendingSignup: {
      upsert: (...args: unknown[]) => mockUpsert(...args),
    },
  },
}));

const mockGenerateCode = vi.fn();
const mockHashCode = vi.fn();
const mockGetExpiry = vi.fn();

vi.mock("@/lib/auth/verificationCode", () => ({
  generateVerificationCode: () => mockGenerateCode(),
  hashVerificationCode: (...args: unknown[]) => mockHashCode(...args),
  getExpiryDate: (...args: unknown[]) => mockGetExpiry(...args),
}));

const mockSendEmail = vi.fn();

vi.mock("@/lib/email/emailService", () => ({
  sendVerificationEmail: (...args: unknown[]) => mockSendEmail(...args),
}));

// ── Helpers ────────────────────────────────────────────────────────────────

function makeRequest(body: unknown): Request {
  return {
    json: () => Promise.resolve(body),
  } as unknown as Request;
}

const futureDate = new Date(Date.now() + 15 * 60 * 1000);
const resendDate = new Date(Date.now() + 5 * 60 * 1000);

const VALID_BODY = {
  email: "newuser@example.com",
  password: "SecurePass1",
  displayName: "New User",
  phone: "9165551234",
};

// ── Setup ──────────────────────────────────────────────────────────────────

beforeEach(() => {
  vi.clearAllMocks();
  mockFindUnique.mockResolvedValue(null);
  mockUpsert.mockResolvedValue({});
  mockGenerateCode.mockReturnValue("123456");
  mockHashCode.mockResolvedValue("$2b$10$hashedcode");
  mockGetExpiry
    .mockReturnValueOnce(futureDate)
    .mockReturnValueOnce(resendDate);
  mockSendEmail.mockResolvedValue(undefined);
});

// ── Tests ──────────────────────────────────────────────────────────────────

describe("POST /api/create_account", () => {
  it("returns 200 with success and email on valid registration", async () => {
    const res = await POST(makeRequest(VALID_BODY) as import("next/server").NextRequest);
    const data = await res.json();

    expect(res.status).toBe(200);
    expect(data.success).toBe(true);
    expect(data.email).toBe("newuser@example.com");
    expect(data.resendAvailableAt).toBeDefined();
  });

  it("normalizes email to lowercase and trimmed before upsert", async () => {
    await POST(
      makeRequest({ ...VALID_BODY, email: "  NewUser@Example.COM  " }) as import("next/server").NextRequest,
    );

    expect(mockUpsert).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { email: "newuser@example.com" },
      }),
    );
  });

  it("sends a verification email after successful signup", async () => {
    await POST(makeRequest(VALID_BODY) as import("next/server").NextRequest);

    expect(mockSendEmail).toHaveBeenCalledWith(
      "newuser@example.com",
      "New User",
      "123456",
    );
  });

  it("falls back to 'there' display name when displayName is omitted", async () => {
    const { displayName: _, ...bodyNoName } = VALID_BODY;
    await POST(makeRequest(bodyNoName) as import("next/server").NextRequest);

    expect(mockSendEmail).toHaveBeenCalledWith(
      expect.any(String),
      "there",
      expect.any(String),
    );
  });

  it("stores CUSTOMER role by default", async () => {
    await POST(makeRequest(VALID_BODY) as import("next/server").NextRequest);

    expect(mockUpsert).toHaveBeenCalledWith(
      expect.objectContaining({
        create: expect.objectContaining({ role: "CUSTOMER" }),
      }),
    );
  });

  it("stores STAFF role when role=STAFF is provided", async () => {
    await POST(
      makeRequest({ ...VALID_BODY, role: "STAFF" }) as import("next/server").NextRequest,
    );

    expect(mockUpsert).toHaveBeenCalledWith(
      expect.objectContaining({
        create: expect.objectContaining({ role: "STAFF" }),
      }),
    );
  });

  it("normalizes phone by stripping non-digit characters", async () => {
    await POST(
      makeRequest({ ...VALID_BODY, phone: "(916) 555-1234" }) as import("next/server").NextRequest,
    );

    expect(mockUpsert).toHaveBeenCalledWith(
      expect.objectContaining({
        create: expect.objectContaining({ phone: "9165551234" }),
      }),
    );
  });

  it("returns 400 when email is missing", async () => {
    const res = await POST(
      makeRequest({ password: "SecurePass1", phone: "9165551234" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toBe("Email and password are required.");
  });

  it("returns 400 when password is missing", async () => {
    const res = await POST(
      makeRequest({ email: "user@example.com", phone: "9165551234" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toBe("Email and password are required.");
  });

  it("returns 400 when password is too short", async () => {
    const res = await POST(
      makeRequest({ ...VALID_BODY, password: "Sh0rt" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toMatch(/at least 8 characters/i);
  });

  it("returns 400 when password has no uppercase letter", async () => {
    const res = await POST(
      makeRequest({ ...VALID_BODY, password: "nouppercase1" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toMatch(/uppercase/i);
  });

  it("returns 400 when password has no digit", async () => {
    const res = await POST(
      makeRequest({ ...VALID_BODY, password: "NoDigitsHere" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toMatch(/number/i);
  });

  it("returns 400 when phone number is missing", async () => {
    const res = await POST(
      makeRequest({ email: VALID_BODY.email, password: VALID_BODY.password }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toBe("Phone number is required.");
  });

  it("returns 400 when phone number is fewer than 10 digits", async () => {
    const res = await POST(
      makeRequest({ ...VALID_BODY, phone: "12345" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toMatch(/too short/i);
  });

  it("returns 400 when phone number is more than 10 digits", async () => {
    const res = await POST(
      makeRequest({ ...VALID_BODY, phone: "91655512341234" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toMatch(/too long/i);
  });

  it("returns 400 when phone starts with 1 and is 11 digits", async () => {
    const res = await POST(
      makeRequest({ ...VALID_BODY, phone: "19165551234" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toMatch(/leading 1/i);
  });

  it("returns 409 when an active account already exists at that email", async () => {
    mockFindUnique.mockResolvedValue({ status: "active" });

    const res = await POST(makeRequest(VALID_BODY) as import("next/server").NextRequest);
    const data = await res.json();

    expect(res.status).toBe(409);
    expect(data.error).toBe("An account with this email already exists.");
  });

  it("does not send an email when a 409 conflict is returned", async () => {
    mockFindUnique.mockResolvedValue({ status: "active" });

    await POST(makeRequest(VALID_BODY) as import("next/server").NextRequest);

    expect(mockSendEmail).not.toHaveBeenCalled();
  });

  it("returns 500 when the database throws during upsert", async () => {
    mockUpsert.mockRejectedValue(new Error("DB connection lost"));

    const res = await POST(makeRequest(VALID_BODY) as import("next/server").NextRequest);
    const data = await res.json();

    expect(res.status).toBe(500);
    expect(data.error).toBe("Account creation failed.");
  });
});
