import { NextResponse } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const { prismaMock, requireStaffSessionMock } = vi.hoisted(() => ({
  prismaMock: {
    category1: {
      findMany: vi.fn(),
    },
  },
  requireStaffSessionMock: vi.fn(),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

vi.mock("@/lib/auth/staffAccess", () => ({
  requireStaffSession: requireStaffSessionMock,
}));

import { GET } from "@/app/api/catalog/staff/types/route";

const routeUrl = "http://localhost/api/catalog/staff/types";

function mockStaffSession() {
  requireStaffSessionMock.mockResolvedValue({
    ok: true,
    account: {
      id: 1,
      email: "staff@example.com",
      displayName: "Staff User",
      role: "STAFF",
      status: "active",
      deletedAt: null,
    },
    normalizedRole: "STAFF",
  });
}

describe("/api/catalog/staff/types route", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockStaffSession();
  });

  it("rejects requests without a staff session", async () => {
    requireStaffSessionMock.mockResolvedValue({
      ok: false,
      response: NextResponse.json(
        { success: false, error: "Unauthorized." },
        { status: 401 },
      ),
    });

    const response = await GET(new Request(routeUrl));
    const body = await response.json();

    expect(response.status).toBe(401);
    expect(body).toEqual({ success: false, error: "Unauthorized." });
    expect(prismaMock.category1.findMany).not.toHaveBeenCalled();
  });

  it("returns an empty types list when category is missing", async () => {
    const response = await GET(
      new Request(`${routeUrl}?subcategory=Power%20Tools`),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({ types: [] });
    expect(prismaMock.category1.findMany).not.toHaveBeenCalled();
  });

  it("returns an empty types list when subcategory is missing", async () => {
    const response = await GET(new Request(`${routeUrl}?category=Tools`));
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({ types: [] });
    expect(prismaMock.category1.findMany).not.toHaveBeenCalled();
  });

  it("returns category type names filtered by category and subcategory", async () => {
    prismaMock.category1.findMany.mockResolvedValue([
      { name: "Angle Grinder" },
      { name: "Cordless Drill" },
      { name: "Impact Driver" },
    ]);

    const response = await GET(
      new Request(`${routeUrl}?category=Tools&subcategory=Power%20Tools`),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      types: ["Angle Grinder", "Cordless Drill", "Impact Driver"],
    });
    expect(prismaMock.category1.findMany).toHaveBeenCalledWith({
      where: {
        category2: {
          name: "Power Tools",
          category3: {
            name: "Tools",
          },
        },
      },
      select: {
        name: true,
      },
      orderBy: {
        name: "asc",
      },
    });
  });
});
