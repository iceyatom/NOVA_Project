import { NextRequest } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const { mockPrisma, mockDeleteFileFromS3 } = vi.hoisted(() => ({
  mockDeleteFileFromS3: vi.fn(),
  mockPrisma: {
    catalogItem: {
      count: vi.fn(),
      findMany: vi.fn(),
      findUnique: vi.fn(),
      create: vi.fn(),
      update: vi.fn(),
      delete: vi.fn(),
    },
    category1: {
      findFirst: vi.fn(),
    },
    category2: {
      findFirst: vi.fn(),
    },
    category3: {
      findUnique: vi.fn(),
    },
    catalogItemImage: {
      count: vi.fn(),
    },
    $transaction: vi.fn(),
  },
}));

vi.mock("@/lib/db", () => ({
  prisma: mockPrisma,
}));

vi.mock("@/lib/s3", () => ({
  deleteFileFromS3: (...args: unknown[]) => mockDeleteFileFromS3(...args),
}));

import { DELETE, GET, PATCH, POST } from "../src/app/api/catalog/route";

function makeRequest(url: string, init?: RequestInit) {
  return new NextRequest(url, init);
}

const validPayload = {
  sku: "SKU-100",
  itemName: "Glass Beaker",
  price: 12.5,
  category3: "Laboratory Supplies",
  category2: "Containers",
  category1: "Beakers",
  classifications: [
    {
      category3: "Laboratory Supplies",
      category2: "Containers",
      category1: "Beakers",
    },
  ],
  description: "500ml beaker",
  quantityInStock: 25,
  unitOfMeasure: "each",
  storageLocation: "A1",
  storageConditions: "Room Temp",
  expirationDate: null,
  dateAcquired: "2026-01-01",
  reorderLevel: 5,
  unitCost: 8.25,
};

describe("catalog API route", () => {
  beforeEach(() => {
    vi.resetAllMocks();
    delete process.env.CATALOG_DATA_SOURCE;
    delete process.env.CATALOG_LAMBDA_BASE_URL;
    delete process.env.API_BASE_URL;
    delete process.env.NEXT_PUBLIC_API_URL;
    delete process.env.DATABASE_URL;
    process.env.S3_BUCKET_NAME = "test-bucket";
    process.env.AWS_REGION = "us-west-2";

    mockPrisma.$transaction.mockImplementation(async (ops: unknown[]) =>
      Promise.all(ops as Promise<unknown>[]),
    );
  });

  // Verifies GET returns config error when neither Prisma nor Lambda is available.
  it("returns 500 when no catalog data source is configured", async () => {
    const response = await GET(makeRequest("http://localhost/api/catalog"));
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.error).toBe("No catalog data source is configured.");
  });

  // Verifies Prisma mode fails fast when DATABASE_URL is missing.
  it("returns 500 when CATALOG_DATA_SOURCE=prisma without DATABASE_URL", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";

    const response = await GET(makeRequest("http://localhost/api/catalog"));
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body.error).toBe(
      "CATALOG_DATA_SOURCE=prisma but DATABASE_URL is not set.",
    );
  });

  // Verifies list GET returns Prisma results with pagination metadata.
  it("returns list data from Prisma in GET", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "postgresql://example";

    mockPrisma.catalogItem.count.mockResolvedValue(1);
    mockPrisma.catalogItem.findMany.mockResolvedValue([
      {
        id: 1,
        itemName: "Glass Beaker",
        category1Ref: { name: "Beakers" },
        category2Ref: { name: "Containers" },
        category3Ref: { name: "Laboratory Supplies" },
        description: "500ml beaker",
        price: 12.5,
        quantityInStock: 25,
        images: [],
      },
    ]);

    const response = await GET(
      makeRequest("http://localhost/api/catalog?limit=20&page=1"),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toMatchObject({
      success: true,
      count: 1,
      totalCount: 1,
      limit: 20,
      offset: 0,
    });
    expect(body.data[0]).toMatchObject({
      id: 1,
      itemName: "Glass Beaker",
      category1: "Beakers",
      category2: "Containers",
      category3: "Laboratory Supplies",
    });
  });

  // Verifies detail GET returns 404 when requested item does not exist.
  it("returns 404 for missing item id in GET", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "postgresql://example";
    mockPrisma.catalogItem.findUnique.mockResolvedValue(null);

    const response = await GET(makeRequest("http://localhost/api/catalog?id=999"));
    const body = await response.json();

    expect(response.status).toBe(404);
    expect(body).toMatchObject({
      success: true,
      data: null,
      totalCount: 0,
    });
  });

  // Verifies POST rejects invalid payloads before any DB writes.
  it("returns 400 for invalid POST payload", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "postgresql://example";

    const response = await POST(
      makeRequest("http://localhost/api/catalog", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ itemName: "Missing SKU" }),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("Invalid create payload.");
  });

  // Verifies POST is blocked in lambda-only mode.
  it("returns 501 for POST when CATALOG_DATA_SOURCE=lambda", async () => {
    process.env.CATALOG_DATA_SOURCE = "lambda";

    const response = await POST(
      makeRequest("http://localhost/api/catalog", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validPayload),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(501);
    expect(body.error).toBe(
      "Catalog creates are only supported with Prisma data source.",
    );
  });

  // Verifies successful POST resolves category path and creates the item.
  it("creates a catalog item via POST", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "postgresql://example";

    mockPrisma.category3.findUnique.mockResolvedValue({ id: 30 });
    mockPrisma.category2.findFirst.mockResolvedValue({ id: 20 });
    mockPrisma.category1.findFirst.mockResolvedValue({ id: 10 });
    mockPrisma.catalogItem.create.mockResolvedValue({
      id: 101,
      sku: "SKU-100",
      itemName: "Glass Beaker",
    });

    const response = await POST(
      makeRequest("http://localhost/api/catalog", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validPayload),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(201);
    expect(body).toMatchObject({
      success: true,
      data: { id: 101, sku: "SKU-100" },
    });
    expect(mockPrisma.catalogItem.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          sku: "SKU-100",
          category1: 10,
          category2: 20,
          category3: 30,
        }),
      }),
    );
  });

  // Verifies PATCH requires a valid id query parameter.
  it("returns 400 for PATCH without id", async () => {
    const response = await PATCH(
      makeRequest("http://localhost/api/catalog", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validPayload),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("A valid id query parameter is required.");
  });

  // Verifies PATCH maps Prisma not-found errors to HTTP 404.
  it("returns 404 when PATCH target item does not exist", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "postgresql://example";

    mockPrisma.category3.findUnique.mockResolvedValue({ id: 30 });
    mockPrisma.category2.findFirst.mockResolvedValue({ id: 20 });
    mockPrisma.category1.findFirst.mockResolvedValue({ id: 10 });
    mockPrisma.catalogItem.update.mockRejectedValue({ code: "P2025" });

    const response = await PATCH(
      makeRequest("http://localhost/api/catalog?id=999", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validPayload),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(404);
    expect(body.error).toBe("Catalog item not found.");
  });

  // Verifies DELETE validates id before attempting payload parsing.
  it("returns 400 for DELETE without id", async () => {
    const response = await DELETE(
      makeRequest("http://localhost/api/catalog", {
        method: "DELETE",
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body.error).toBe("A valid id query parameter is required.");
  });

  // Verifies DELETE returns 404 when item does not exist.
  it("returns 404 when DELETE target item is missing", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "postgresql://example";
    mockPrisma.catalogItem.findUnique.mockResolvedValue(null);

    const response = await DELETE(
      makeRequest("http://localhost/api/catalog?id=77", {
        method: "DELETE",
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(404);
    expect(body.error).toBe("Catalog item not found.");
  });

  // Verifies DELETE can clean up unreferenced S3 images when requested.
  it("deletes item and removes unreferenced image from storage", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "postgresql://example";

    mockPrisma.catalogItem.findUnique.mockResolvedValue({
      id: 5,
      images: [{ s3Key: "img/a.png" }],
    });
    mockPrisma.catalogItem.delete.mockResolvedValue({ id: 5 });
    mockPrisma.catalogItemImage.count.mockResolvedValue(0);
    mockDeleteFileFromS3.mockResolvedValue(undefined);

    const response = await DELETE(
      makeRequest("http://localhost/api/catalog?id=5", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ deleteImagesFromStorage: true }),
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toMatchObject({
      success: true,
      data: {
        id: 5,
        deletedImageCount: 1,
        storageCleanupErrors: [],
      },
    });
    expect(mockDeleteFileFromS3).toHaveBeenCalledWith("img/a.png");
  });

  // Verifies DELETE maps foreign-key conflicts to an actionable 409 response.
  it("returns 409 when DELETE is blocked by ticket history references", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "postgresql://example";

    mockPrisma.catalogItem.findUnique.mockResolvedValue({
      id: 9,
      images: [],
    });
    mockPrisma.catalogItem.delete.mockRejectedValue({ code: "P2003" });

    const response = await DELETE(
      makeRequest("http://localhost/api/catalog?id=9", {
        method: "DELETE",
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(409);
    expect(body.error).toBe(
      "Catalog item cannot be deleted because it is referenced by existing ticket history.",
    );
  });
});
