import { NextRequest, NextResponse } from "next/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const { prismaMock, requireStaffSessionMock, s3SendMock } = vi.hoisted(() => ({
  prismaMock: {
    catalogItem: {
      findMany: vi.fn(),
      findUnique: vi.fn(),
    },
    catalogItemImage: {
      aggregate: vi.fn(),
      count: vi.fn(),
      create: vi.fn(),
      delete: vi.fn(),
      findFirst: vi.fn(),
      findMany: vi.fn(),
      findUnique: vi.fn(),
      groupBy: vi.fn(),
      update: vi.fn(),
    },
    $transaction: vi.fn(),
  },
  requireStaffSessionMock: vi.fn(),
  s3SendMock: vi.fn(),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

vi.mock("@/lib/auth/staffAccess", () => ({
  requireStaffSession: requireStaffSessionMock,
}));

vi.mock("@/lib/awsCredentials", () => ({
  getAwsCredentials: vi.fn(() => undefined),
}));

vi.mock("@aws-sdk/client-s3", () => ({
  DeleteObjectCommand: vi.fn((input) => ({ input })),
  S3Client: vi.fn(function S3Client() {
    return {
      send: s3SendMock,
    };
  }),
}));

import {
  DELETE,
  GET,
  PATCH,
  POST,
} from "@/app/api/catalog/staff/images/route";

const routeUrl = "http://localhost/api/catalog/staff/images";

function mockStaffSession() {
  requireStaffSessionMock.mockResolvedValue({
    ok: true,
    account: {
      id: 1,
      email: "staff@example.com",
      displayName: "Staff User",
      role: "STAFF",
      status: "active",
      deletedAt: null,
    },
    normalizedRole: "STAFF",
  });
}

function jsonRequest(
  method: "POST" | "PATCH" | "DELETE",
  body: Record<string, unknown>,
) {
  return new NextRequest(routeUrl, {
    method,
    body: JSON.stringify(body),
    headers: {
      "content-type": "application/json",
    },
  });
}

describe("/api/catalog/staff/images route", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.AWS_REGION = "us-west-2";
    process.env.S3_BUCKET_NAME = "nova-test-bucket";
    mockStaffSession();
  });

  it("rejects requests without a staff session", async () => {
    requireStaffSessionMock.mockResolvedValue({
      ok: false,
      response: NextResponse.json(
        { success: false, error: "Unauthorized." },
        { status: 401 },
      ),
    });

    const response = await GET(new NextRequest(routeUrl));
    const body = await response.json();

    expect(response.status).toBe(401);
    expect(body).toEqual({ success: false, error: "Unauthorized." });
    expect(prismaMock.catalogItemImage.groupBy).not.toHaveBeenCalled();
  });

  it("validates catalogItemId on image library GET requests", async () => {
    const response = await GET(
      new NextRequest(`${routeUrl}?catalogItemId=abc`),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body).toEqual({
      success: false,
      error: "catalogItemId must be a positive integer when provided.",
    });
    expect(prismaMock.catalogItemImage.groupBy).not.toHaveBeenCalled();
  });

  it("lists reusable images with S3 URLs, usage counts, and linked status", async () => {
    const linkedAt = new Date("2024-03-01T10:00:00.000Z");
    prismaMock.catalogItemImage.groupBy
      .mockResolvedValueOnce([
        {
          s3Key: "catalog/items/drill.png",
          _count: { s3Key: 1 },
          _max: { createdAt: linkedAt },
        },
      ])
      .mockResolvedValueOnce([
        {
          s3Key: "catalog/items/drill.png",
          _count: { s3Key: 3 },
          _max: { createdAt: linkedAt },
        },
      ]);
    prismaMock.catalogItemImage.findMany.mockResolvedValue([
      { s3Key: "catalog/items/drill.png" },
    ]);

    const response = await GET(
      new NextRequest(`${routeUrl}?catalogItemId=42&limit=10`),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      success: true,
      data: [
        {
          s3Key: "catalog/items/drill.png",
          url: "https://nova-test-bucket.s3.us-west-2.amazonaws.com/catalog/items/drill.png",
          usageCount: 3,
          lastLinkedAt: linkedAt.toISOString(),
          linkedToCatalogItem: true,
        },
      ],
    });
    expect(prismaMock.catalogItemImage.groupBy).toHaveBeenNthCalledWith(1, {
      by: ["s3Key"],
      where: {
        s3Key: { not: "" },
      },
      _count: {
        s3Key: true,
      },
      _max: {
        createdAt: true,
      },
      orderBy: {
        _max: {
          createdAt: "desc",
        },
      },
      take: 10,
    });
  });

  it("links a new image to a catalog item with the next sort order", async () => {
    prismaMock.catalogItem.findUnique.mockResolvedValue({ id: 42 });
    prismaMock.catalogItemImage.findFirst.mockResolvedValue(null);
    prismaMock.catalogItemImage.aggregate.mockResolvedValue({
      _max: { sortOrder: 4 },
    });
    prismaMock.catalogItemImage.create.mockResolvedValue({
      id: 9,
      catalogItemId: 42,
      s3Key: "catalog/items/drill.png",
      sortOrder: 5,
    });

    const response = await POST(
      jsonRequest("POST", {
        catalogItemId: 42,
        fileKey: " catalog/items/drill.png ",
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(201);
    expect(body).toEqual({
      success: true,
      data: {
        id: 9,
        catalogItemId: 42,
        s3Key: "catalog/items/drill.png",
        sortOrder: 5,
      },
      alreadyLinked: false,
    });
    expect(prismaMock.catalogItemImage.create).toHaveBeenCalledWith({
      data: {
        catalogItemId: 42,
        s3Key: "catalog/items/drill.png",
        sortOrder: 5,
      },
    });
  });

  it("rejects duplicate image IDs when reordering images", async () => {
    const response = await PATCH(
      jsonRequest("PATCH", {
        catalogItemId: 42,
        imageIds: [9, 9],
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body).toEqual({
      success: false,
      error: "imageIds must not include duplicates",
    });
    expect(prismaMock.$transaction).not.toHaveBeenCalled();
  });

  it("unlinks an image record without deleting from S3 when not requested", async () => {
    prismaMock.catalogItemImage.findUnique.mockResolvedValue({
      id: 9,
      s3Key: "catalog/items/drill.png",
    });
    prismaMock.catalogItemImage.delete.mockResolvedValue({
      id: 9,
      s3Key: "catalog/items/drill.png",
    });

    const response = await DELETE(
      jsonRequest("DELETE", {
        imageId: 9,
        deleteFromStorage: false,
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      success: true,
      data: {
        id: 9,
        deletedFromStorage: false,
      },
    });
    expect(prismaMock.catalogItemImage.delete).toHaveBeenCalledWith({
      where: { id: 9 },
    });
    expect(prismaMock.catalogItemImage.count).not.toHaveBeenCalled();
    expect(s3SendMock).not.toHaveBeenCalled();
  });
});
