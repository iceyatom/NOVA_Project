import { POST } from "../src/app/api/verify-email/route";

// ── Mocks ──────────────────────────────────────────────────────────────────

const mockPendingSignupFindUnique = vi.fn();
const mockPendingSignupDelete = vi.fn();
const mockAccountFindUnique = vi.fn();
const mockAccountCreate = vi.fn();
const mockAccountUpdate = vi.fn();
const mockPendingVerificationDelete = vi.fn();
const mockPendingVerificationDeleteMany = vi.fn();
const mockTransaction = vi.fn();

vi.mock("@/lib/prisma", () => ({
  prisma: {
    pendingSignup: {
      findUnique: (...args: unknown[]) => mockPendingSignupFindUnique(...args),
      delete: (...args: unknown[]) => mockPendingSignupDelete(...args),
    },
    account: {
      findUnique: (...args: unknown[]) => mockAccountFindUnique(...args),
      create: (...args: unknown[]) => mockAccountCreate(...args),
      update: (...args: unknown[]) => mockAccountUpdate(...args),
    },
    pendingVerification: {
      delete: (...args: unknown[]) => mockPendingVerificationDelete(...args),
      deleteMany: (...args: unknown[]) => mockPendingVerificationDeleteMany(...args),
    },
    $transaction: (...args: unknown[]) => mockTransaction(...args),
  },
}));

const mockVerifyCode = vi.fn();

vi.mock("@/lib/auth/verificationCode", () => ({
  verifyVerificationCode: (...args: unknown[]) => mockVerifyCode(...args),
}));

// ── Helpers ────────────────────────────────────────────────────────────────

function makeRequest(body: unknown): Request {
  return {
    json: () => Promise.resolve(body),
  } as unknown as Request;
}

function makeThrowingRequest(): Request {
  return {
    json: () => Promise.reject(new SyntaxError("bad json")),
  } as unknown as Request;
}

const futureDate = new Date(Date.now() + 10 * 60 * 1000);
const pastDate = new Date(Date.now() - 1 * 60 * 1000);

const validPendingSignup = {
  email: "newuser@example.com",
  passwordHash: "$2b$10$hashedpassword",
  role: "CUSTOMER",
  displayName: "New User",
  phone: "9165551234",
  codeHash: "$2b$10$hashedcode",
  expiresAt: futureDate,
};

// ── Setup ──────────────────────────────────────────────────────────────────

beforeEach(() => {
  vi.clearAllMocks();
  mockPendingSignupFindUnique.mockResolvedValue(null);
  mockAccountFindUnique.mockResolvedValue(null);
  mockVerifyCode.mockResolvedValue(false);
  mockTransaction.mockImplementation(async (fn: (tx: unknown) => unknown) => {
    const tx = {
      account: {
        findUnique: mockAccountFindUnique,
        create: mockAccountCreate,
        update: mockAccountUpdate,
      },
      pendingSignup: { delete: mockPendingSignupDelete },
      pendingVerification: {
        delete: mockPendingVerificationDelete,
        deleteMany: mockPendingVerificationDeleteMany,
      },
    };
    return fn(tx);
  });
});

// ── Tests ──────────────────────────────────────────────────────────────────

describe("POST /api/verify-email", () => {
  it("returns 400 when JSON body is malformed", async () => {
    const res = await POST(makeThrowingRequest() as import("next/server").NextRequest);
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.ok).toBe(false);
    expect(data.error).toBe("Invalid JSON body.");
  });

  it("returns 400 when both email and code are missing", async () => {
    const res = await POST(makeRequest({}) as import("next/server").NextRequest);
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.ok).toBe(false);
    expect(data.error).toBe("Email and code are required.");
  });

  it("returns 400 when email is missing", async () => {
    const res = await POST(makeRequest({ code: "123456" }) as import("next/server").NextRequest);
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toBe("Email and code are required.");
  });

  it("returns 400 when code is missing", async () => {
    const res = await POST(
      makeRequest({ email: "user@example.com" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toBe("Email and code are required.");
  });

  it("returns 400 when no pendingSignup and no pending account exist", async () => {
    mockPendingSignupFindUnique.mockResolvedValue(null);
    mockAccountFindUnique.mockResolvedValue(null);

    const res = await POST(
      makeRequest({ email: "ghost@example.com", code: "000000" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.ok).toBe(false);
    expect(data.error).toBe("Invalid or expired verification code.");
  });

  it("returns 400 when pendingSignup code is expired", async () => {
    mockPendingSignupFindUnique.mockResolvedValue({
      ...validPendingSignup,
      expiresAt: pastDate,
    });

    const res = await POST(
      makeRequest({ email: "newuser@example.com", code: "123456" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toBe("Invalid or expired verification code.");
  });

  it("returns 400 when the submitted code does not match stored hash", async () => {
    mockPendingSignupFindUnique.mockResolvedValue(validPendingSignup);
    mockVerifyCode.mockResolvedValue(false);

    const res = await POST(
      makeRequest({ email: "newuser@example.com", code: "999999" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toBe("Invalid or expired verification code.");
  });

  it("returns 200 ok:true when pendingSignup matches and account is created", async () => {
    mockPendingSignupFindUnique.mockResolvedValue(validPendingSignup);
    mockVerifyCode.mockResolvedValue(true);
    mockAccountFindUnique.mockResolvedValue(null);
    mockAccountCreate.mockResolvedValue({ id: 1 });
    mockPendingSignupDelete.mockResolvedValue({});

    const res = await POST(
      makeRequest({ email: "newuser@example.com", code: "123456" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(200);
    expect(data.ok).toBe(true);
  });

  it("normalizes email to lowercase and trims whitespace before lookup", async () => {
    mockPendingSignupFindUnique.mockResolvedValue(null);
    mockAccountFindUnique.mockResolvedValue(null);

    await POST(
      makeRequest({ email: "  NewUser@Example.COM  ", code: "123456" }) as import("next/server").NextRequest,
    );

    expect(mockPendingSignupFindUnique).toHaveBeenCalledWith(
      expect.objectContaining({ where: { email: "newuser@example.com" } }),
    );
  });

  it("returns 400 (unified error) when account is already active — prevents enumeration", async () => {
    mockPendingSignupFindUnique.mockResolvedValue(null);
    mockAccountFindUnique.mockResolvedValue({
      id: 1,
      status: "active",
      pendingVerification: null,
    });

    const res = await POST(
      makeRequest({ email: "active@example.com", code: "123456" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toBe("Invalid or expired verification code.");
  });

  it("falls back to legacy pendingVerification path when no pendingSignup exists", async () => {
    const legacyAccount = {
      id: 99,
      status: "pending",
      pendingVerification: {
        codeHash: "$2b$10$legacyhash",
        expiresAt: futureDate,
        accountId: 99,
      },
    };

    mockPendingSignupFindUnique.mockResolvedValue(null);
    mockAccountFindUnique.mockResolvedValue(legacyAccount);
    mockVerifyCode.mockResolvedValue(true);
    mockTransaction.mockResolvedValue(undefined);

    const res = await POST(
      makeRequest({ email: "legacy@example.com", code: "654321" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(200);
    expect(data.ok).toBe(true);
  });

  it("returns 400 when legacy pendingVerification code is expired", async () => {
    mockPendingSignupFindUnique.mockResolvedValue(null);
    mockAccountFindUnique.mockResolvedValue({
      id: 99,
      status: "pending",
      pendingVerification: {
        codeHash: "$2b$10$hash",
        expiresAt: pastDate,
        accountId: 99,
      },
    });

    const res = await POST(
      makeRequest({ email: "legacy@example.com", code: "123456" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(400);
    expect(data.error).toBe("Invalid or expired verification code.");
  });

  it("returns 500 when an unexpected DB error occurs during lookup", async () => {
    mockPendingSignupFindUnique.mockRejectedValue(new Error("DB crashed"));

    const res = await POST(
      makeRequest({ email: "user@example.com", code: "123456" }) as import("next/server").NextRequest,
    );
    const data = await res.json();

    expect(res.status).toBe(500);
    expect(data.ok).toBe(false);
    expect(data.error).toBe("Unable to verify code.");
  });
});
