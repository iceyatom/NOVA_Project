import { afterAll, beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest, NextResponse } from "next/server";

const { mockRequireStaffSession, mockPrisma } = vi.hoisted(() => {
  const mockCount = vi.fn();
  const mockFindMany = vi.fn();
  const mockTransaction = vi.fn(
    async (operations: Array<Promise<unknown>>) => Promise.all(operations),
  );

  return {
    mockRequireStaffSession: vi.fn(),
    mockPrisma: {
      catalogItem: {
        count: mockCount,
        findMany: mockFindMany,
      },
      $transaction: mockTransaction,
    },
  };
});

const fetchMock = vi.fn();

vi.mock("@/lib/auth/staffAccess", () => ({
  requireStaffSession: mockRequireStaffSession,
}));

vi.mock("@/lib/db", () => ({
  prisma: mockPrisma,
}));

vi.stubGlobal("fetch", fetchMock);

import { GET } from "@/app/api/catalog/staff/route";

function makeRequest(path: string) {
  return new NextRequest(`http://localhost${path}`);
}

function authorizedStaff() {
  return {
    ok: true as const,
    account: {
      id: 1,
      email: "staff@example.com",
      displayName: "Staff User",
      role: "STAFF",
      status: "active",
      deletedAt: null,
    },
    normalizedRole: "STAFF" as const,
  };
}

function expectNoCacheHeaders(response: Response) {
  expect(response.headers.get("cache-control")).toBe(
    "no-store, no-cache, must-revalidate, proxy-revalidate",
  );
  expect(response.headers.get("pragma")).toBe("no-cache");
  expect(response.headers.get("expires")).toBe("0");
}

const originalEnv = {
  DATABASE_URL: process.env.DATABASE_URL,
  CATALOG_DATA_SOURCE: process.env.CATALOG_DATA_SOURCE,
  CATALOG_LAMBDA_BASE_URL: process.env.CATALOG_LAMBDA_BASE_URL,
  API_BASE_URL: process.env.API_BASE_URL,
  NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL,
};

describe("/api/catalog/staff route", () => {
  beforeEach(() => {
    vi.clearAllMocks();

    process.env.DATABASE_URL = "";
    process.env.CATALOG_DATA_SOURCE = "";
    process.env.CATALOG_LAMBDA_BASE_URL = "";
    process.env.API_BASE_URL = "";
    process.env.NEXT_PUBLIC_API_URL = "";

    mockRequireStaffSession.mockResolvedValue(authorizedStaff());
  });

  it("returns the auth response when requireStaffSession fails", async () => {
    mockRequireStaffSession.mockResolvedValueOnce({
      ok: false,
      response: NextResponse.json(
        { success: false, error: "Unauthorized." },
        { status: 401 },
      ),
    });

    const response = await GET(makeRequest("/api/catalog/staff"));
    const body = await response.json();

    expect(response.status).toBe(401);
    expect(body).toEqual({
      success: false,
      error: "Unauthorized.",
    });
    expect(mockPrisma.catalogItem.count).not.toHaveBeenCalled();
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("returns 500 in prisma mode when DATABASE_URL is missing", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "";

    const response = await GET(makeRequest("/api/catalog/staff"));
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body).toEqual({
      success: false,
      error: "DATABASE_URL is not set for prisma mode.",
    });
    expectNoCacheHeaders(response);
  });

  it("uses prisma mode with default paging and default sort", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "mysql://test:test@localhost:3306/testdb";

    const updatedAt = new Date("2026-02-01T10:00:00.000Z");

    mockPrisma.catalogItem.count.mockResolvedValueOnce(1);
    mockPrisma.catalogItem.findMany.mockResolvedValueOnce([
      {
        id: 101,
        sku: "BULLFROG-001",
        itemName: "Bullfrog Specimen",
        quantityInStock: 5,
        price: 49.99,
        updatedAt,
        category1Ref: { name: "Biology" },
        category2Ref: { name: "Dissection" },
        category3Ref: { name: "Specimens" },
        classifications: [],
      },
    ]);

    const response = await GET(makeRequest("/api/catalog/staff"));
    const body = await response.json();

    expect(mockRequireStaffSession).toHaveBeenCalledWith(["ADMIN", "STAFF"]);

    expect(mockPrisma.catalogItem.count).toHaveBeenCalledWith({ where: undefined });
    expect(mockPrisma.catalogItem.findMany).toHaveBeenCalledWith({
      where: undefined,
      orderBy: { id: "asc" },
      skip: 0,
      take: 20,
      select: expect.any(Object),
    });

    expect(response.status).toBe(200);
    expect(body).toEqual({
      success: true,
      data: [
        {
          id: 101,
          sku: "BULLFROG-001",
          itemName: "Bullfrog Specimen",
          category1: "Biology",
          category2: "Dissection",
          category3: "Specimens",
          quantityInStock: 5,
          price: 49.99,
          updatedAt: updatedAt.toISOString(),
        },
      ],
      totalCount: 1,
      limit: 20,
      offset: 0,
    });
    expectNoCacheHeaders(response);
  });

  it("builds prisma search/category filters and uses classification path when it matches filters better than the primary path", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "mysql://test:test@localhost:3306/testdb";

    const updatedAt = new Date("2026-02-02T10:00:00.000Z");

    mockPrisma.catalogItem.count.mockResolvedValueOnce(1);
    mockPrisma.catalogItem.findMany.mockResolvedValueOnce([
      {
        id: 202,
        sku: "KIT-002",
        itemName: "Bullfrog Dissection Kit",
        quantityInStock: 8,
        price: 129.99,
        updatedAt,
        category1Ref: { name: "Lab Supplies" },
        category2Ref: { name: "Preserved Animals" },
        category3Ref: { name: "Amphibians" },
        classifications: [
          {
            category1: {
              name: "Biology",
              category2: {
                name: "Dissection",
                category3: {
                  name: "Specimens",
                },
              },
            },
          },
        ],
      },
    ]);

    const response = await GET(
      makeRequest(
        "/api/catalog/staff?pageSize=50&offset=10&query=bullfrog%20kit&category=Specimens&subcategory=Dissection&type=Biology&sortBy=category&sortOrder=desc",
      ),
    );

    const body = await response.json();

    expect(mockPrisma.catalogItem.count).toHaveBeenCalledWith({
      where: {
        AND: [
          {
            OR: [
              { itemName: { contains: "bullfrog" } },
              { sku: { contains: "bullfrog" } },
            ],
          },
          {
            OR: [
              { itemName: { contains: "kit" } },
              { sku: { contains: "kit" } },
            ],
          },
          {
            OR: [
              {
                AND: [
                  { category3Ref: { is: { name: "Specimens" } } },
                  { category2Ref: { is: { name: "Dissection" } } },
                  { category1Ref: { is: { name: "Biology" } } },
                ],
              },
              {
                classifications: {
                  some: {
                    category1: {
                      is: {
                        name: "Biology",
                        category2: {
                          is: {
                            name: "Dissection",
                            category3: {
                              is: {
                                name: "Specimens",
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            ],
          },
        ],
      },
    });

    expect(mockPrisma.catalogItem.findMany).toHaveBeenCalledWith({
      where: {
        AND: [
          {
            OR: [
              { itemName: { contains: "bullfrog" } },
              { sku: { contains: "bullfrog" } },
            ],
          },
          {
            OR: [
              { itemName: { contains: "kit" } },
              { sku: { contains: "kit" } },
            ],
          },
          {
            OR: [
              {
                AND: [
                  { category3Ref: { is: { name: "Specimens" } } },
                  { category2Ref: { is: { name: "Dissection" } } },
                  { category1Ref: { is: { name: "Biology" } } },
                ],
              },
              {
                classifications: {
                  some: {
                    category1: {
                      is: {
                        name: "Biology",
                        category2: {
                          is: {
                            name: "Dissection",
                            category3: {
                              is: {
                                name: "Specimens",
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            ],
          },
        ],
      },
      orderBy: [
        { category1Ref: { name: "desc" } },
        { category2Ref: { name: "desc" } },
        { category3Ref: { name: "desc" } },
        { itemName: "desc" },
      ],
      skip: 10,
      take: 50,
      select: expect.any(Object),
    });

    expect(body).toEqual({
      success: true,
      data: [
        {
          id: 202,
          sku: "KIT-002",
          itemName: "Bullfrog Dissection Kit",
          category1: "Biology",
          category2: "Dissection",
          category3: "Specimens",
          quantityInStock: 8,
          price: 129.99,
          updatedAt: updatedAt.toISOString(),
        },
      ],
      totalCount: 1,
      limit: 50,
      offset: 10,
    });
  });

  it("supports pageSize=all in prisma mode by omitting take and using totalCount as limit", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "mysql://test:test@localhost:3306/testdb";

    mockPrisma.catalogItem.count.mockResolvedValueOnce(2);
    mockPrisma.catalogItem.findMany.mockResolvedValueOnce([
      {
        id: 1,
        sku: "PIG-001",
        itemName: "Fetal Pig Specimen",
        quantityInStock: 1,
        price: 10,
        updatedAt: new Date("2026-02-01T00:00:00.000Z"),
        category1Ref: null,
        category2Ref: null,
        category3Ref: null,
        classifications: [],
      },
      {
        id: 2,
        sku: "CRAYFISH-002",
        itemName: "Crayfish Specimen",
        quantityInStock: 2,
        price: 20,
        updatedAt: new Date("2026-02-02T00:00:00.000Z"),
        category1Ref: null,
        category2Ref: null,
        category3Ref: null,
        classifications: [],
      },
    ]);

    const response = await GET(makeRequest("/api/catalog/staff?pageSize=all"));
    const body = await response.json();

    expect(mockPrisma.catalogItem.findMany).toHaveBeenCalledWith({
      where: undefined,
      orderBy: { id: "asc" },
      skip: 0,
      take: undefined,
      select: expect.any(Object),
    });

    expect(body.limit).toBe(2);
    expect(body.totalCount).toBe(2);
  });

  it("returns 500 when prisma query fails in prisma mode", async () => {
    process.env.CATALOG_DATA_SOURCE = "prisma";
    process.env.DATABASE_URL = "mysql://test:test@localhost:3306/testdb";

    mockPrisma.catalogItem.count.mockRejectedValueOnce(new Error("Prisma blew up"));

    const response = await GET(makeRequest("/api/catalog/staff"));
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body).toEqual({
      success: false,
      error: "Prisma staff catalog query failed.",
      details: "Prisma blew up",
    });
  });

  it("returns 500 in lambda mode when the base URL is missing", async () => {
    process.env.CATALOG_DATA_SOURCE = "lambda";
    process.env.CATALOG_LAMBDA_BASE_URL = "";
    process.env.API_BASE_URL = "";
    process.env.NEXT_PUBLIC_API_URL = "";

    const response = await GET(makeRequest("/api/catalog/staff"));
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body).toEqual({
      success: false,
      error: "Lambda base URL is not set for lambda mode.",
    });
  });

  it("uses lambda mode, forwards query params, and preserves upstream status", async () => {
    process.env.CATALOG_DATA_SOURCE = "lambda";
    process.env.CATALOG_LAMBDA_BASE_URL = "https://lambda.example.com";

    fetchMock.mockResolvedValueOnce(
      new Response(
        JSON.stringify({
          data: [
            {
              id: 500,
              itemName: "Dissection Tray Set",
            },
          ],
          totalCount: 99,
        }),
        {
          status: 206,
          headers: {
            "content-type": "application/json",
          },
        },
      ),
    );

    const response = await GET(
      makeRequest(
        "/api/catalog/staff?pageSize=50&offset=5&query=frog%20tray&sortBy=price&sortOrder=desc&category=Tools&subcategory=Dissection&type=Biology",
      ),
    );

    const body = await response.json();

    expect(fetchMock).toHaveBeenCalledTimes(1);

    const calledUrl = String(fetchMock.mock.calls[0][0]);
    const calledInit = fetchMock.mock.calls[0][1];

    expect(calledUrl).toContain("https://lambda.example.com/catalog");
    expect(calledUrl).toContain("limit=50");
    expect(calledUrl).toContain("offset=5");
    expect(calledUrl).toContain("q=frog+tray");
    expect(calledUrl).toContain("sortBy=price");
    expect(calledUrl).toContain("sortOrder=desc");
    expect(calledUrl).toContain("categories=Tools%2CDissection%2CBiology");

    expect(calledInit).toEqual({ cache: "no-store" });

    expect(response.status).toBe(206);
    expect(body).toEqual({
      success: true,
      data: [
        {
          id: 500,
          itemName: "Dissection Tray Set",
        },
      ],
      totalCount: 99,
      limit: 50,
      offset: 5,
    });
    expectNoCacheHeaders(response);
  });

  it("passes through non-JSON lambda responses as raw text", async () => {
    process.env.CATALOG_DATA_SOURCE = "lambda";
    process.env.CATALOG_LAMBDA_BASE_URL = "https://lambda.example.com/catalog";

    fetchMock.mockResolvedValueOnce(
      new Response("upstream plain text error", {
        status: 502,
        headers: {
          "content-type": "text/plain",
        },
      }),
    );

    const response = await GET(makeRequest("/api/catalog/staff"));
    const text = await response.text();

    expect(response.status).toBe(502);
    expect(text).toBe("upstream plain text error");
    expect(response.headers.get("content-type")).toContain("text/plain");
    expectNoCacheHeaders(response);
  });

  it("returns 502 when lambda fetch throws in lambda mode", async () => {
    process.env.CATALOG_DATA_SOURCE = "lambda";
    process.env.CATALOG_LAMBDA_BASE_URL = "https://lambda.example.com";

    fetchMock.mockRejectedValueOnce(new Error("lambda unavailable"));

    const response = await GET(makeRequest("/api/catalog/staff"));
    const body = await response.json();

    expect(response.status).toBe(502);
    expect(body).toEqual({
      success: false,
      error: "Lambda staff catalog request failed.",
      details: "lambda unavailable",
    });
  });

  it("falls back from prisma to lambda in auto mode", async () => {
    process.env.CATALOG_DATA_SOURCE = "auto";
    process.env.DATABASE_URL = "mysql://test:test@localhost:3306/testdb";
    process.env.CATALOG_LAMBDA_BASE_URL = "https://lambda.example.com";

    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    mockPrisma.catalogItem.count.mockRejectedValueOnce(new Error("primary db offline"));

    fetchMock.mockResolvedValueOnce(
      new Response(
        JSON.stringify({
          data: [{ id: 77, itemName: "Forceps Starter Pack" }],
          totalCount: 1,
        }),
        {
          status: 200,
          headers: { "content-type": "application/json" },
        },
      ),
    );

    const response = await GET(makeRequest("/api/catalog/staff"));
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      success: true,
      data: [{ id: 77, itemName: "Forceps Starter Pack" }],
      totalCount: 1,
      limit: 20,
      offset: 0,
    });
    expect(fetchMock).toHaveBeenCalledTimes(1);

    errorSpy.mockRestore();
  });

  it("returns a combined 502 error in auto mode when both prisma and lambda fail", async () => {
    process.env.CATALOG_DATA_SOURCE = "auto";
    process.env.DATABASE_URL = "mysql://test:test@localhost:3306/testdb";
    process.env.CATALOG_LAMBDA_BASE_URL = "https://lambda.example.com";

    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    mockPrisma.catalogItem.count.mockRejectedValueOnce(new Error("db down"));
    fetchMock.mockRejectedValueOnce(new Error("lambda down"));

    const response = await GET(makeRequest("/api/catalog/staff"));
    const body = await response.json();

    expect(response.status).toBe(502);
    expect(body).toEqual({
      success: false,
      error: "Both Prisma and Lambda staff catalog requests failed.",
      details: "Prisma: db down | Lambda: lambda down",
    });

    errorSpy.mockRestore();
  });

  it("returns 500 in auto mode when no data source is configured", async () => {
    process.env.CATALOG_DATA_SOURCE = "auto";
    process.env.DATABASE_URL = "";
    process.env.CATALOG_LAMBDA_BASE_URL = "";
    process.env.API_BASE_URL = "";
    process.env.NEXT_PUBLIC_API_URL = "";

    const response = await GET(makeRequest("/api/catalog/staff"));
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body).toEqual({
      success: false,
      error: "No staff catalog data source is configured.",
      details: "Set DATABASE_URL or CATALOG_LAMBDA_BASE_URL.",
    });
  });
});

afterAll(() => {
  process.env.DATABASE_URL = originalEnv.DATABASE_URL;
  process.env.CATALOG_DATA_SOURCE = originalEnv.CATALOG_DATA_SOURCE;
  process.env.CATALOG_LAMBDA_BASE_URL = originalEnv.CATALOG_LAMBDA_BASE_URL;
  process.env.API_BASE_URL = originalEnv.API_BASE_URL;
  process.env.NEXT_PUBLIC_API_URL = originalEnv.NEXT_PUBLIC_API_URL;
});