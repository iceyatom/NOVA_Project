// articlesStaffRoute.test.ts
import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest, NextResponse } from "next/server";

const { prismaMock, requireStaffSessionMock } = vi.hoisted(() => {
  return {
    prismaMock: {
      article: {
        findUnique: vi.fn(),
        findMany: vi.fn(),
        create: vi.fn(),
        update: vi.fn(),
        delete: vi.fn(),
      },
    },
    requireStaffSessionMock: vi.fn(),
  };
});

vi.mock("@/lib/db", () => ({
  prisma: prismaMock,
}));

vi.mock("@/lib/auth/staffAccess", () => ({
  requireStaffSession: requireStaffSessionMock,
}));

import { GET, POST, PATCH, DELETE } from "@/app/api/articles/staff/route";

function makeAuthorizedAuth(role: "ADMIN" | "STAFF" = "STAFF") {
  return {
    ok: true as const,
    account: {
      id: 123,
      role,
      email: "staff@example.com",
      displayName: "Alex Staff",
    },
  };
}

function makeUnauthorizedAuth() {
  return {
    ok: false as const,
    response: NextResponse.json(
      { success: false, error: "Unauthorized" },
      { status: 401 },
    ),
  };
}

function makeRequest(
  method: "GET" | "POST" | "PATCH" | "DELETE",
  url = "http://localhost/api/articles/staff",
  body?: unknown,
) {
  return new NextRequest(url, {
    method,
    body: body === undefined ? undefined : JSON.stringify(body),
    headers:
      body === undefined
        ? undefined
        : { "Content-Type": "application/json" },
  });
}

async function jsonOf(response: Response) {
  return response.json();
}

describe("staff articles route", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("GET", () => {
    it("returns a single article for a valid id", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.article.findUnique.mockResolvedValue({
        id: 1,
        type: "INFO",
        title: "Valid title",
        body: "Valid body",
        author: "Alex Staff",
        createdAt: new Date("2026-04-24T10:00:00.000Z"),
        modifiedAt: new Date("2026-04-24T10:00:00.000Z"),
      });

      const res = await GET(
        makeRequest("GET", "http://localhost/api/articles/staff?id=1"),
      );
      expect(res.status).toBe(200);
    });

    it("returns list with default limit", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.article.findMany.mockResolvedValue([]);

      const res = await GET(
        makeRequest("GET", "http://localhost/api/articles/staff"),
      );
      expect(res.status).toBe(200);
    });

    it("returns 400 for invalid id (string)", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const res = await GET(
        makeRequest("GET", "http://localhost/api/articles/staff?id=abc"),
      );
      expect(res.status).toBe(400);
    });

    it("returns 400 for invalid id (negative)", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const res = await GET(
        makeRequest("GET", "http://localhost/api/articles/staff?id=-1"),
      );
      expect(res.status).toBe(400);
    });

    it("returns 400 for invalid type filter", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const res = await GET(
        makeRequest("GET", "http://localhost/api/articles/staff?type=invalid"),
      );
      expect(res.status).toBe(400);
    });

    it("returns 404 if article not found", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.article.findUnique.mockResolvedValue(null);

      const res = await GET(
        makeRequest("GET", "http://localhost/api/articles/staff?id=999"),
      );
      expect(res.status).toBe(404);
    });

    it("returns 401 if unauthorized", async () => {
      requireStaffSessionMock.mockResolvedValue(makeUnauthorizedAuth());

      const res = await GET(
        makeRequest("GET", "http://localhost/api/articles/staff"),
      );
      expect(res.status).toBe(401);
    });
  });

  describe("POST", () => {
    it("creates article (valid)", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.article.create.mockResolvedValue({
        id: 1,
        type: "INFO",
        title: "Valid",
        author: "Alex Staff",
        createdAt: new Date("2026-04-24T10:00:00.000Z"),
        modifiedAt: new Date("2026-04-24T10:00:00.000Z"),
      });

      const res = await POST(
        makeRequest("POST", "http://localhost/api/articles/staff", {
          type: "info",
          title: "Valid",
          body: "Valid body",
        }),
      );

      expect(res.status).toBe(201);
    });

    it("returns 400 for invalid JSON", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const req = new NextRequest("http://localhost/api/articles/staff", {
        method: "POST",
        body: "{bad",
        headers: { "Content-Type": "application/json" },
      });

      const res = await POST(req);
      expect(res.status).toBe(400);
    });

    it("returns 400 for invalid type", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const res = await POST(
        makeRequest("POST", "http://localhost/api/articles/staff", {
          type: "blog",
          title: "Valid",
          body: "Valid",
        }),
      );

      expect(res.status).toBe(400);
    });

    it("returns 400 for missing title", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const res = await POST(
        makeRequest("POST", "http://localhost/api/articles/staff", {
          type: "info",
          title: "",
          body: "Valid",
        }),
      );

      expect(res.status).toBe(400);
    });

    it("returns 400 for blank body", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const res = await POST(
        makeRequest("POST", "http://localhost/api/articles/staff", {
          type: "info",
          title: "Valid",
          body: "   ",
        }),
      );

      expect(res.status).toBe(400);
    });

    it("returns 500 on DB failure", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.article.create.mockRejectedValue(new Error("DB failure"));

      const res = await POST(
        makeRequest("POST", "http://localhost/api/articles/staff", {
          type: "info",
          title: "Valid",
          body: "Valid",
        }),
      );

      expect(res.status).toBe(500);
    });
  });

  describe("PATCH", () => {
    it("updates article (valid)", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.article.update.mockResolvedValue({
        id: 1,
        type: "INFO",
        title: "Updated",
        body: "Updated",
        author: "Alex Staff",
        createdAt: new Date("2026-04-24T10:00:00.000Z"),
        modifiedAt: new Date("2026-04-24T11:00:00.000Z"),
      });

      const res = await PATCH(
        makeRequest("PATCH", "http://localhost/api/articles/staff?id=1", {
          type: "info",
          title: "Updated",
          body: "Updated",
        }),
      );

      expect(res.status).toBe(200);
    });

    it("returns 400 for missing id", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const res = await PATCH(
        makeRequest("PATCH", "http://localhost/api/articles/staff", {
          type: "info",
          title: "Valid",
          body: "Valid",
        }),
      );

      expect(res.status).toBe(400);
    });

    it("returns 404 if article not found", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.article.update.mockRejectedValue({ code: "P2025" });

      const res = await PATCH(
        makeRequest("PATCH", "http://localhost/api/articles/staff?id=999", {
          type: "info",
          title: "Valid",
          body: "Valid",
        }),
      );

      expect(res.status).toBe(404);
    });
  });

  describe("DELETE", () => {
    it("deletes article (valid)", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.article.delete.mockResolvedValue({ id: 1, title: "Deleted" });

      const res = await DELETE(
        makeRequest("DELETE", "http://localhost/api/articles/staff?id=1"),
      );
      expect(res.status).toBe(200);
    });

    it("returns 400 for missing id", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const res = await DELETE(
        makeRequest("DELETE", "http://localhost/api/articles/staff"),
      );
      expect(res.status).toBe(400);
    });

    it("returns 404 if not found", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.article.delete.mockRejectedValue({ code: "P2025" });

      const res = await DELETE(
        makeRequest("DELETE", "http://localhost/api/articles/staff?id=999"),
      );
      expect(res.status).toBe(404);
    });
  });
});