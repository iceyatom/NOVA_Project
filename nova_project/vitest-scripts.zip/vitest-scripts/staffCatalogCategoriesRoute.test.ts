// categoryRoute.test.ts
import { beforeEach, describe, expect, it, vi } from "vitest";
import { NextRequest, NextResponse } from "next/server";

const { prismaMock, requireStaffSessionMock } = vi.hoisted(() => {
  return {
    prismaMock: {
      category3: {
        findMany: vi.fn(),
        findUnique: vi.fn(),
        create: vi.fn(),
        update: vi.fn(),
        delete: vi.fn(),
      },
      category2: {
        findFirst: vi.fn(),
        count: vi.fn(),
        create: vi.fn(),
        update: vi.fn(),
        delete: vi.fn(),
      },
      category1: {
        findFirst: vi.fn(),
        count: vi.fn(),
        create: vi.fn(),
        update: vi.fn(),
        delete: vi.fn(),
      },
    },
    requireStaffSessionMock: vi.fn(),
  };
});

vi.mock("@/lib/db", () => ({
  prisma: prismaMock,
}));

vi.mock("@/lib/auth/staffAccess", () => ({
  requireStaffSession: requireStaffSessionMock,
}));

import { GET, POST, PATCH, DELETE } from "@/app/api/catalog/staff/categories/route"; // adjust path if needed

function makeAuthorizedAuth(role: "ADMIN" | "STAFF" = "STAFF") {
  return {
    ok: true as const,
    account: {
      id: 123,
      role,
      email: "staff@example.com",
      displayName: "Alex Staff",
    },
  };
}

function makeUnauthorizedAuth(status = 401, error = "Unauthorized") {
  return {
    ok: false as const,
    response: NextResponse.json({ success: false, error }, { status }),
  };
}

function makeRequest(
  method: "GET" | "POST" | "PATCH" | "DELETE",
  url = "http://localhost/api/categories/staff",
  body?: unknown,
) {
  return new NextRequest(url, {
    method,
    body: body === undefined ? undefined : JSON.stringify(body),
    headers:
      body === undefined
        ? undefined
        : { "Content-Type": "application/json" },
  });
}

async function jsonOf(response: Response) {
  return response.json();
}

describe("category management route", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("GET", () => {
    it("returns hierarchy successfully", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      prismaMock.category3.findMany.mockResolvedValue([
        {
          name: "Electronics",
          category2s: [
            {
              name: "Laptops",
              category1s: [{ name: "Gaming" }],
            },
          ],
        },
      ]);

      const response = await GET(
        makeRequest(
          "GET",
          "http://localhost/api/categories/staff?action=hierarchy",
        ),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(200);
      expect(body).toEqual({
        success: true,
        data: {
          categories: ["Electronics"],
          subcategories: [
            { name: "Laptops", parentCategory3: "Electronics" },
          ],
          types: [
            {
              name: "Gaming",
              parentCategory3: "Electronics",
              parentCategory2: "Laptops",
            },
          ],
        },
      });
    });

    it("returns dependency counts for category3", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.category3.findUnique.mockResolvedValue({ id: 10 });
      prismaMock.category2.count.mockResolvedValue(2);
      prismaMock.category1.count.mockResolvedValue(5);

      const response = await GET(
        makeRequest(
          "GET",
          "http://localhost/api/categories/staff?action=dependencies&level=category3&name=Electronics",
        ),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(200);
      expect(body).toEqual({
        success: true,
        data: {
          level: "category3",
          subcategoryCount: 2,
          typeCount: 5,
        },
      });
    });

    it("passes through auth failure", async () => {
      requireStaffSessionMock.mockResolvedValue(makeUnauthorizedAuth());

      const response = await GET(
        makeRequest(
          "GET",
          "http://localhost/api/categories/staff?action=hierarchy",
        ),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(401);
      expect(body).toEqual({
        success: false,
        error: "Unauthorized",
      });
    });

    it("returns 400 for invalid category level", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const response = await GET(
        makeRequest(
          "GET",
          "http://localhost/api/categories/staff?action=dependencies&level=bad&name=Electronics",
        ),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(400);
      expect(body.error).toBe("Invalid category level.");
    });

    it("returns 500 when hierarchy load fails", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.category3.findMany.mockRejectedValue(new Error("DB failure"));

      const response = await GET(
        makeRequest(
          "GET",
          "http://localhost/api/categories/staff?action=hierarchy",
        ),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(500);
      expect(body.error).toBe("Failed to load category hierarchy.");
    });
  });

  describe("POST", () => {
    it("creates a category3 successfully", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.category3.findUnique.mockResolvedValue(null);
      prismaMock.category3.create.mockResolvedValue({
        id: 1,
        name: "Electronics",
      });

      const response = await POST(
        makeRequest("POST", "http://localhost/api/categories/staff", {
          level: "category3",
          name: "Electronics",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(201);
      expect(body).toEqual({
        success: true,
        data: {
          level: "category3",
          id: 1,
          name: "Electronics",
        },
      });
    });

    it("creates a category1 successfully", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.category3.findUnique.mockResolvedValue({
        id: 10,
        name: "Electronics",
      });
      prismaMock.category2.findFirst.mockResolvedValueOnce({
        id: 20,
        name: "Laptops",
      });
      prismaMock.category1.findFirst.mockResolvedValue(null);
      prismaMock.category1.create.mockResolvedValue({
        id: 3,
        name: "Gaming",
      });

      const response = await POST(
        makeRequest("POST", "http://localhost/api/categories/staff", {
          level: "category1",
          name: "Gaming",
          parentCategory3: "Electronics",
          parentCategory2: "Laptops",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(201);
      expect(body).toEqual({
        success: true,
        data: {
          level: "category1",
          id: 3,
          name: "Gaming",
          parentCategory3: "Electronics",
          parentCategory2: "Laptops",
        },
      });
    });

    it("returns 400 for invalid POST body", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const request = new NextRequest("http://localhost/api/categories/staff", {
        method: "POST",
        body: "{bad-json",
        headers: { "Content-Type": "application/json" },
      });

      const response = await POST(request);
      const body = await jsonOf(response);

      expect(response.status).toBe(400);
      expect(body).toEqual({
        success: false,
        error: "Invalid request body.",
        details: "Expected JSON payload.",
      });
    });

    it("returns 400 when required parent is missing", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const response = await POST(
        makeRequest("POST", "http://localhost/api/categories/staff", {
          level: "category1",
          name: "Gaming",
          parentCategory3: "Electronics",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(400);
      expect(body.error).toBe("Parent Subcategory is required.");
    });

    it("returns 409 when duplicate category3 exists", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.category3.findUnique.mockResolvedValue({ id: 1 });

      const response = await POST(
        makeRequest("POST", "http://localhost/api/categories/staff", {
          level: "category3",
          name: "Electronics",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(409);
      expect(body.error).toBe("Category already exists.");
    });

    it("returns 500 for unexpected POST failure", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.category3.findUnique.mockResolvedValue(null);
      prismaMock.category3.create.mockRejectedValue(new Error("DB failure"));

      const response = await POST(
        makeRequest("POST", "http://localhost/api/categories/staff", {
          level: "category3",
          name: "Electronics",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(500);
      expect(body.error).toBe("Failed to create category.");
    });
  });

  describe("PATCH", () => {
    it("updates a category3 successfully", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.category3.findUnique.mockResolvedValue({
        id: 1,
        name: "Electronics",
      });
      prismaMock.category3.update.mockResolvedValue({
        id: 1,
        name: "Computers",
      });

      const response = await PATCH(
        makeRequest("PATCH", "http://localhost/api/categories/staff", {
          level: "category3",
          currentName: "Electronics",
          newName: "Computers",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(200);
      expect(body).toEqual({
        success: true,
        data: {
          level: "category3",
          name: "Computers",
        },
      });
    });

    it("returns 400 when names are missing", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const response = await PATCH(
        makeRequest("PATCH", "http://localhost/api/categories/staff", {
          level: "category3",
          currentName: "Electronics",
          newName: "   ",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(400);
      expect(body.error).toBe("Current and new category names are required.");
    });

    it("returns 404 when target category is not found", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.category3.findUnique.mockResolvedValue(null);

      const response = await PATCH(
        makeRequest("PATCH", "http://localhost/api/categories/staff", {
          level: "category3",
          currentName: "Missing",
          newName: "New Name",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(404);
      expect(body.error).toBe("Category not found.");
    });

    it("returns 409 for duplicate rename conflict", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.category3.findUnique.mockResolvedValue({
        id: 1,
        name: "Electronics",
      });
      prismaMock.category3.update.mockRejectedValue({ code: "P2002" });

      const response = await PATCH(
        makeRequest("PATCH", "http://localhost/api/categories/staff", {
          level: "category3",
          currentName: "Electronics",
          newName: "Computers",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(409);
      expect(body.error).toBe(
        "A category with this name already exists under the selected parent.",
      );
    });
  });

  describe("DELETE", () => {
    it("deletes a category3 successfully", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.category3.findUnique.mockResolvedValue({
        id: 1,
        name: "Electronics",
      });
      prismaMock.category2.count.mockResolvedValue(2);
      prismaMock.category1.count.mockResolvedValue(5);
      prismaMock.category3.delete.mockResolvedValue({});

      const response = await DELETE(
        makeRequest("DELETE", "http://localhost/api/categories/staff", {
          level: "category3",
          name: "Electronics",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(200);
      expect(body).toEqual({
        success: true,
        data: {
          level: "category3",
          name: "Electronics",
          subcategoryCount: 2,
          typeCount: 5,
        },
      });
    });

    it("returns 400 when delete name is missing", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());

      const response = await DELETE(
        makeRequest("DELETE", "http://localhost/api/categories/staff", {
          level: "category3",
          name: "   ",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(400);
      expect(body.error).toBe("Category name is required.");
    });

    it("returns 404 when delete target is not found", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.category3.findUnique.mockResolvedValue(null);

      const response = await DELETE(
        makeRequest("DELETE", "http://localhost/api/categories/staff", {
          level: "category3",
          name: "Missing",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(404);
      expect(body.error).toBe("Category not found.");
    });

    it("returns 500 for unexpected DELETE failure", async () => {
      requireStaffSessionMock.mockResolvedValue(makeAuthorizedAuth());
      prismaMock.category3.findUnique.mockResolvedValue({
        id: 1,
        name: "Electronics",
      });
      prismaMock.category2.count.mockResolvedValue(2);
      prismaMock.category1.count.mockResolvedValue(5);
      prismaMock.category3.delete.mockRejectedValue(new Error("DB failure"));

      const response = await DELETE(
        makeRequest("DELETE", "http://localhost/api/categories/staff", {
          level: "category3",
          name: "Electronics",
        }),
      );
      const body = await jsonOf(response);

      expect(response.status).toBe(500);
      expect(body.error).toBe("Failed to delete category.");
    });
  });
});