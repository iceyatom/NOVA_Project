import { GET } from "../src/app/api/catalog/categories/route";

// ── Mocks ──────────────────────────────────────────────────────────────────

const mockFindMany = vi.fn();

vi.mock("@/lib/db", () => ({
  prisma: {
    category3: {
      findMany: (...args: unknown[]) => mockFindMany(...args),
    },
  },
}));

// ── Tests ──────────────────────────────────────────────────────────────────

beforeEach(() => {
  vi.clearAllMocks();
});

describe("GET /api/catalog/categories", () => {
  it("returns success with an ordered list of category names", async () => {
    mockFindMany.mockResolvedValue([
      { name: "Dissecting Kits" },
      { name: "Laboratory Supplies" },
      { name: "Live Algae Specimens" },
    ]);

    const res = await GET();
    const data = await res.json();

    expect(res.status).toBe(200);
    expect(data.success).toBe(true);
    expect(Array.isArray(data.categories)).toBe(true);
    expect(data.categories).toEqual([
      "Dissecting Kits",
      "Laboratory Supplies",
      "Live Algae Specimens",
    ]);
  });

  it("returns success with an empty array when no categories exist", async () => {
    mockFindMany.mockResolvedValue([]);

    const res = await GET();
    const data = await res.json();

    expect(res.status).toBe(200);
    expect(data.success).toBe(true);
    expect(data.categories).toEqual([]);
  });

  it("returns success with a single category", async () => {
    mockFindMany.mockResolvedValue([{ name: "Live Vertebrates" }]);

    const res = await GET();
    const data = await res.json();

    expect(res.status).toBe(200);
    expect(data.success).toBe(true);
    expect(data.categories).toHaveLength(1);
    expect(data.categories[0]).toBe("Live Vertebrates");
  });

  it("returns 500 and structured error when the database throws", async () => {
    mockFindMany.mockRejectedValue(new Error("Connection refused"));

    const res = await GET();
    const data = await res.json();

    expect(res.status).toBe(500);
    expect(data.success).toBe(false);
    expect(data.categories).toEqual([]);
    expect(data.error).toBe("Failed to load category options.");
    expect(data.details).toBe("Connection refused");
  });

  it("includes a generic details message for non-Error throws", async () => {
    mockFindMany.mockRejectedValue("unexpected string error");

    const res = await GET();
    const data = await res.json();

    expect(res.status).toBe(500);
    expect(data.success).toBe(false);
    expect(data.details).toBe("Unknown category lookup error");
  });

  it("calls prisma with name ascending order and only selects name", async () => {
    mockFindMany.mockResolvedValue([]);

    await GET();

    expect(mockFindMany).toHaveBeenCalledWith({
      select: { name: true },
      orderBy: { name: "asc" },
    });
  });
});
