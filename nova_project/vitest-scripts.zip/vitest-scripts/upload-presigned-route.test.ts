import { NextRequest } from "next/server";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { generatePresignedUrlMock } = vi.hoisted(() => ({
  generatePresignedUrlMock: vi.fn(),
}));

vi.mock("@/lib/s3", () => ({
  ALLOWED_IMAGE_TYPES: [
    "image/jpeg",
    "image/jpg",
    "image/png",
    "image/gif",
    "image/webp",
  ],
  MAX_FILE_SIZE: 10_485_760,
  generatePresignedUrl: generatePresignedUrlMock,
}));

import {
  DELETE,
  GET,
  POST,
  PUT,
} from "@/app/api/upload/presigned/route";

const routeUrl = "http://localhost/api/upload/presigned";

function jsonRequest(body: Record<string, unknown>) {
  return new NextRequest(routeUrl, {
    method: "POST",
    body: JSON.stringify(body),
    headers: {
      "content-type": "application/json",
    },
  });
}

describe("/api/upload/presigned route", () => {
  let consoleErrorSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    vi.clearAllMocks();
    consoleErrorSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    generatePresignedUrlMock.mockResolvedValue({
      presignedUrl: "https://s3.example.test/presigned",
      fileUrl: "https://s3.example.test/uploads/test-image.png",
      fileKey: "uploads/test-image.png",
    });
  });

  afterEach(() => {
    consoleErrorSpy.mockRestore();
  });

  it("requires fileName", async () => {
    const response = await POST(
      jsonRequest({
        fileType: "image/png",
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body).toEqual({
      success: false,
      error: "fileName is required and must be a string",
    });
    expect(generatePresignedUrlMock).not.toHaveBeenCalled();
  });

  it("requires fileType", async () => {
    const response = await POST(
      jsonRequest({
        fileName: "test-image.png",
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body).toEqual({
      success: false,
      error: "fileType is required and must be a string",
    });
    expect(generatePresignedUrlMock).not.toHaveBeenCalled();
  });

  it("rejects unsupported file types", async () => {
    const response = await POST(
      jsonRequest({
        fileName: "document.pdf",
        fileType: "application/pdf",
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body).toEqual({
      success: false,
      error:
        "Invalid file type. Allowed types: image/jpeg, image/jpg, image/png, image/gif, image/webp",
    });
    expect(generatePresignedUrlMock).not.toHaveBeenCalled();
  });

  it("rejects invalid custom maxFileSize values", async () => {
    const response = await POST(
      jsonRequest({
        fileName: "test-image.png",
        fileType: "image/png",
        maxFileSize: -1,
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body).toEqual({
      success: false,
      error: "maxFileSize must be a positive number",
    });
    expect(generatePresignedUrlMock).not.toHaveBeenCalled();
  });

  it("rejects custom maxFileSize above the configured maximum", async () => {
    const response = await POST(
      jsonRequest({
        fileName: "test-image.png",
        fileType: "image/png",
        maxFileSize: 10_485_761,
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(400);
    expect(body).toEqual({
      success: false,
      error: "maxFileSize cannot exceed 10485760 bytes (10.0MB)",
    });
    expect(generatePresignedUrlMock).not.toHaveBeenCalled();
  });

  it("returns presigned upload metadata for a valid image request", async () => {
    const response = await POST(
      jsonRequest({
        fileName: "test-image.png",
        fileType: "image/png",
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(200);
    expect(body).toEqual({
      success: true,
      presignedUrl: "https://s3.example.test/presigned",
      fileUrl: "https://s3.example.test/uploads/test-image.png",
      fileKey: "uploads/test-image.png",
      expiresIn: 900,
    });
    expect(generatePresignedUrlMock).toHaveBeenCalledWith(
      "test-image.png",
      "image/png",
    );
  });

  it("returns a configuration error when S3 bucket setup is missing", async () => {
    generatePresignedUrlMock.mockRejectedValue(
      new Error("S3_BUCKET_NAME environment variable is not set"),
    );

    const response = await POST(
      jsonRequest({
        fileName: "test-image.png",
        fileType: "image/png",
      }),
    );
    const body = await response.json();

    expect(response.status).toBe(500);
    expect(body).toEqual({
      success: false,
      error: "Server configuration error: S3 bucket not configured",
    });
  });

  it("rejects unsupported HTTP methods", async () => {
    const expectedBody = {
      success: false,
      error: "Method not allowed. Use POST to generate a presigned URL.",
    };

    await expect(GET().then((response) => response.json())).resolves.toEqual(
      expectedBody,
    );
    await expect(PUT().then((response) => response.json())).resolves.toEqual(
      expectedBody,
    );
    await expect(
      DELETE().then((response) => response.json()),
    ).resolves.toEqual(expectedBody);
  });
});
