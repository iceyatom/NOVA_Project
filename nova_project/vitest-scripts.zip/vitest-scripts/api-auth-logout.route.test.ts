import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { mockDeleteMany, mockCookies } = vi.hoisted(() => {
  return {
    mockDeleteMany: vi.fn(),
    mockCookies: vi.fn(),
  };
});

vi.mock("@/lib/db", () => ({
  prisma: {
    session: {
      deleteMany: mockDeleteMany,
    },
  },
}));

vi.mock("next/headers", () => ({
  cookies: mockCookies,
}));

import { POST } from "@/app/api/auth/logout/route";

function makeCookieStore(sessionValue?: string) {
  return {
    get: vi.fn((name: string) => {
      if (name !== "session" || !sessionValue) return undefined;
      return { value: sessionValue };
    }),
  };
}

describe("/api/auth/logout route", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.stubEnv("NODE_ENV", "test");
  });

  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it("returns ok and clears the session cookie even when there is no session token", async () => {
    mockCookies.mockResolvedValueOnce(makeCookieStore());

    const response = await POST();
    const body = await response.json();
    const setCookie = response.headers.get("set-cookie") ?? "";

    expect(body).toEqual({ ok: true });
    expect(response.status).toBe(200);
    expect(mockDeleteMany).not.toHaveBeenCalled();

    expect(setCookie).toContain("session=");
    expect(setCookie).toContain("Max-Age=0");
    expect(setCookie).toContain("HttpOnly");
    expect(setCookie).toContain("SameSite=lax");
    expect(setCookie).toContain("Path=/");
  });

  it("deletes the current session token and clears the cookie", async () => {
    mockCookies.mockResolvedValueOnce(makeCookieStore("token-123"));
    mockDeleteMany.mockResolvedValueOnce({ count: 1 });

    const response = await POST();
    const body = await response.json();
    const setCookie = response.headers.get("set-cookie") ?? "";

    expect(mockDeleteMany).toHaveBeenCalledWith({
      where: { token: "token-123" },
    });

    expect(response.status).toBe(200);
    expect(body).toEqual({ ok: true });
    expect(setCookie).toContain("session=");
    expect(setCookie).toContain("Max-Age=0");
  });

  it("still returns ok and clears the cookie when session deletion throws", async () => {
    mockCookies.mockResolvedValueOnce(makeCookieStore("token-123"));
    mockDeleteMany.mockRejectedValueOnce(new Error("db unavailable"));

    const errorSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    const response = await POST();
    const body = await response.json();
    const setCookie = response.headers.get("set-cookie") ?? "";

    expect(response.status).toBe(200);
    expect(body).toEqual({ ok: true });
    expect(setCookie).toContain("session=");
    expect(setCookie).toContain("Max-Age=0");
    expect(errorSpy).toHaveBeenCalled();

    errorSpy.mockRestore();
  });

  it("sets a Secure cookie in production", async () => {
    vi.stubEnv("NODE_ENV", "production");
    mockCookies.mockResolvedValueOnce(makeCookieStore("token-123"));
    mockDeleteMany.mockResolvedValueOnce({ count: 1 });

    const response = await POST();
    const setCookie = response.headers.get("set-cookie") ?? "";

    expect(setCookie).toContain("Secure");
  });
});