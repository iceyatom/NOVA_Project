import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { POST } from "@/app/api/auth/login/route";

// Mocks

vi.mock("@/lib/db", () => ({
  prisma: {
    account: {
      findUnique: vi.fn(),
      update: vi.fn(),
    },
    $transaction: vi.fn(),
    session: {
      create: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth/passwordHash", () => ({
  hashPassword: vi.fn(),
  verifyPassword: vi.fn(),
}));

import { prisma } from "@/lib/db";
import { hashPassword, verifyPassword } from "@/lib/auth/passwordHash";

// Helpers

function makeRequest(body: unknown): Request {
  return new Request("http://localhost/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

function makeInvalidJsonRequest(): Request {
  return new Request("http://localhost/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: "not-json{{{{",
  });
}

// Fixtures

const mockAccount = {
  id: 1,
  email: "user@example.com",
  displayName: "Test User",
  role: "employee",
  passwordHash: "$2b$12$hashedpassword",
  status: "active",
  deletedAt: null,
  failedLoginAttempts: 0,
  lockoutUntil: null,
};

// Tests

describe("POST /api/auth/login", () => {
  const originalDatabaseUrl = process.env.DATABASE_URL;

  beforeEach(() => {
    vi.clearAllMocks();
    process.env.DATABASE_URL = "mysql://test:test@localhost:3306/testdb";
    // Default: session creation succeeds
    vi.mocked(prisma.session.create).mockResolvedValue({} as never);
    vi.mocked(prisma.account.update).mockResolvedValue({} as never);
  });

  afterEach(() => {
    process.env.DATABASE_URL = originalDatabaseUrl;
  });

  // Configuration

  describe("configuration check", () => {
    it("returns 500 when DATABASE_URL is not set", async () => {
      process.env.DATABASE_URL = "";
      const res = await POST(makeRequest({ email: "user@example.com", password: "pass" }));
      expect(res.status).toBe(500);
      const body = await res.json();
      expect(body.ok).toBe(false);
      expect(body.error).toMatch(/not configured/i);
    });

    it("returns 500 when DATABASE_URL is whitespace only", async () => {
      process.env.DATABASE_URL = "   ";
      const res = await POST(makeRequest({ email: "user@example.com", password: "pass" }));
      expect(res.status).toBe(500);
    });
  });

  // Request parsing

  describe("request parsing", () => {
    it("returns 400 for an invalid JSON body", async () => {
      const res = await POST(makeInvalidJsonRequest());
      expect(res.status).toBe(400);
      const body = await res.json();
      expect(body.ok).toBe(false);
      expect(body.error).toMatch(/invalid json/i);
    });

    it("returns 400 when email is missing", async () => {
      const res = await POST(makeRequest({ password: "secret" }));
      expect(res.status).toBe(400);
      const body = await res.json();
      expect(body.error).toMatch(/email and password are required/i);
    });

    it("returns 400 when password is missing", async () => {
      const res = await POST(makeRequest({ email: "user@example.com" }));
      expect(res.status).toBe(400);
      const body = await res.json();
      expect(body.error).toMatch(/email and password are required/i);
    });

    it("returns 400 when both fields are missing", async () => {
      const res = await POST(makeRequest({}));
      expect(res.status).toBe(400);
      const body = await res.json();
      expect(body.error).toMatch(/email and password are required/i);
    });

    it("returns 400 when email is an empty string", async () => {
      const res = await POST(makeRequest({ email: "   ", password: "pass" }));
      expect(res.status).toBe(400);
    });

    it("normalizes email to lowercase and strips whitespace", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(null);
      await POST(makeRequest({ email: "  USER@EXAMPLE.COM  ", password: "pass" }));
      expect(prisma.account.findUnique).toHaveBeenCalledWith(
        expect.objectContaining({ where: { email: "user@example.com" } }),
      );
    });
  });

  // Account lookup

  describe("account lookup", () => {
    it("returns 401 when no account is found", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(null);
      const res = await POST(makeRequest({ email: "nobody@example.com", password: "pass" }));
      expect(res.status).toBe(401);
      const body = await res.json();
      expect(body.error).toMatch(/invalid email or password/i);
    });

    it("returns 401 when account is soft-deleted", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue({
        ...mockAccount,
        deletedAt: new Date(),
      });
      const res = await POST(makeRequest({ email: "user@example.com", password: "pass" }));
      expect(res.status).toBe(401);
      const body = await res.json();
      expect(body.error).toMatch(/invalid email or password/i);
    });

    it("returns 401 when account status is not 'active'", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue({
        ...mockAccount,
        status: "suspended",
      });
      const res = await POST(makeRequest({ email: "user@example.com", password: "pass" }));
      expect(res.status).toBe(401);
    });
  });

  // Lockout

  describe("lockout enforcement", () => {
    it("returns 429 when account is already locked out", async () => {
      const lockoutUntil = new Date(Date.now() + 5 * 60 * 1000);
      vi.mocked(prisma.account.findUnique).mockResolvedValue({
        ...mockAccount,
        lockoutUntil,
      });
      const res = await POST(makeRequest({ email: "user@example.com", password: "pass" }));
      expect(res.status).toBe(429);
      const body = await res.json();
      expect(body.ok).toBe(false);
      expect(body.locked).toBe(true);
      expect(body.lockoutUntil).toBe(lockoutUntil.toISOString());
    });
  });

  // Password verification

  describe("password verification", () => {
    it("returns 401 on wrong password for a bcrypt-hashed account", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(mockAccount);
      vi.mocked(verifyPassword).mockResolvedValue(false);
      vi.mocked(prisma.$transaction).mockImplementation(async (fn: (tx: unknown) => unknown) => {
        return fn({
          account: {
            findUnique: vi.fn().mockResolvedValue({ failedLoginAttempts: 0, lockoutUntil: null }),
            update: vi.fn().mockResolvedValue({ failedLoginAttempts: 1, lockoutUntil: null }),
          },
        });
      });

      const res = await POST(makeRequest({ email: "user@example.com", password: "wrong" }));
      expect(res.status).toBe(401);
      const body = await res.json();
      expect(body.ok).toBe(false);
      expect(body.error).toMatch(/invalid email or password/i);
    });

    it("locks account for 60 seconds after 3 failed attempts", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(mockAccount);
      vi.mocked(verifyPassword).mockResolvedValue(false);
      const lockoutUntil = new Date(Date.now() + 60 * 1000);
      vi.mocked(prisma.$transaction).mockImplementation(async (fn: (tx: unknown) => unknown) => {
        return fn({
          account: {
            findUnique: vi.fn().mockResolvedValue({ failedLoginAttempts: 2, lockoutUntil: null }),
            update: vi.fn().mockResolvedValue({ failedLoginAttempts: 3, lockoutUntil }),
          },
        });
      });

      const res = await POST(makeRequest({ email: "user@example.com", password: "wrong" }));
      expect(res.status).toBe(429);
      const body = await res.json();
      expect(body.locked).toBe(true);
      expect(body.error).toMatch(/60 seconds/i);
    });

    it("locks account for 5 minutes after 4+ failed attempts", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(mockAccount);
      vi.mocked(verifyPassword).mockResolvedValue(false);
      const lockoutUntil = new Date(Date.now() + 5 * 60 * 1000);
      vi.mocked(prisma.$transaction).mockImplementation(async (fn: (tx: unknown) => unknown) => {
        return fn({
          account: {
            findUnique: vi.fn().mockResolvedValue({ failedLoginAttempts: 3, lockoutUntil: null }),
            update: vi.fn().mockResolvedValue({ failedLoginAttempts: 4, lockoutUntil }),
          },
        });
      });

      const res = await POST(makeRequest({ email: "user@example.com", password: "wrong" }));
      expect(res.status).toBe(429);
      const body = await res.json();
      expect(body.locked).toBe(true);
      expect(body.error).toMatch(/5 minutes/i);
    });

    it("returns 401 when an already-locked tx state is detected during failure processing", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(mockAccount);
      vi.mocked(verifyPassword).mockResolvedValue(false);
      const lockoutUntil = new Date(Date.now() + 60 * 1000);
      // The transaction finds the account is already locked mid-flight
      vi.mocked(prisma.$transaction).mockImplementation(async (fn: (tx: unknown) => unknown) => {
        return fn({
          account: {
            findUnique: vi.fn().mockResolvedValue({ failedLoginAttempts: 3, lockoutUntil }),
            update: vi.fn(),
          },
        });
      });

      const res = await POST(makeRequest({ email: "user@example.com", password: "wrong" }));
      // The route returns 429 because the tx detects lockoutUntil is still active
      expect(res.status).toBe(429);
    });

    it("returns 401 on wrong legacy plaintext password", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue({
        ...mockAccount,
        passwordHash: "plaintextpassword",
      });
      vi.mocked(prisma.$transaction).mockImplementation(async (fn: (tx: unknown) => unknown) => {
        return fn({
          account: {
            findUnique: vi.fn().mockResolvedValue({ failedLoginAttempts: 0, lockoutUntil: null }),
            update: vi.fn().mockResolvedValue({ failedLoginAttempts: 1, lockoutUntil: null }),
          },
        });
      });

      const res = await POST(makeRequest({ email: "user@example.com", password: "wrongpassword" }));
      expect(res.status).toBe(401);
    });
  });

  // Successful login

  describe("successful login", () => {
    it("returns 200 with account data on valid bcrypt login", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(mockAccount);
      vi.mocked(verifyPassword).mockResolvedValue(true);

      const res = await POST(makeRequest({ email: "user@example.com", password: "correct" }));
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.ok).toBe(true);
      expect(body.account).toMatchObject({
        id: mockAccount.id,
        email: mockAccount.email,
        displayName: mockAccount.displayName,
        role: mockAccount.role,
      });
      expect(body.role).toBe(mockAccount.role);
    });

    it("sets a session cookie on successful login", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(mockAccount);
      vi.mocked(verifyPassword).mockResolvedValue(true);

      const res = await POST(makeRequest({ email: "user@example.com", password: "correct" }));
      expect(res.status).toBe(200);
      expect(res.headers.get("set-cookie")).toMatch(/session=/);
    });

    it("sets no-cache headers on all responses", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(mockAccount);
      vi.mocked(verifyPassword).mockResolvedValue(true);

      const res = await POST(makeRequest({ email: "user@example.com", password: "correct" }));
      expect(res.headers.get("Cache-Control")).toMatch(/no-store/);
      expect(res.headers.get("Pragma")).toBe("no-cache");
    });

    it("resets failedLoginAttempts and lockoutUntil on successful login", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(mockAccount);
      vi.mocked(verifyPassword).mockResolvedValue(true);

      await POST(makeRequest({ email: "user@example.com", password: "correct" }));
      expect(prisma.account.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ failedLoginAttempts: 0, lockoutUntil: null }),
        }),
      );
    });

    it("does not include passwordHash in the response body", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(mockAccount);
      vi.mocked(verifyPassword).mockResolvedValue(true);

      const res = await POST(makeRequest({ email: "user@example.com", password: "correct" }));
      const body = await res.json();
      expect(JSON.stringify(body)).not.toContain("passwordHash");
    });

    it("upgrades a legacy plaintext password to a bcrypt hash on login", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue({
        ...mockAccount,
        passwordHash: "correctplaintext",
      });
      vi.mocked(hashPassword).mockResolvedValue("$2b$12$newhashedpassword");

      const res = await POST(makeRequest({ email: "user@example.com", password: "correctplaintext" }));
      expect(res.status).toBe(200);
      expect(hashPassword).toHaveBeenCalledWith("correctplaintext");
      expect(prisma.account.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ passwordHash: "$2b$12$newhashedpassword" }),
        }),
      );
    });

    it("does not call hashPassword for an already bcrypt-hashed password", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(mockAccount);
      vi.mocked(verifyPassword).mockResolvedValue(true);

      await POST(makeRequest({ email: "user@example.com", password: "correct" }));
      expect(hashPassword).not.toHaveBeenCalled();
    });

    it("still returns 200 even when session creation fails", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(mockAccount);
      vi.mocked(verifyPassword).mockResolvedValue(true);
      vi.mocked(prisma.session.create).mockRejectedValue(new Error("DB error"));

      const res = await POST(makeRequest({ email: "user@example.com", password: "correct" }));
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.ok).toBe(true);
    });
  });

  // Database errors

  describe("database errors", () => {
    it("returns 500 when prisma throws on account lookup", async () => {
      vi.mocked(prisma.account.findUnique).mockRejectedValue(new Error("DB connection lost"));
      const res = await POST(makeRequest({ email: "user@example.com", password: "pass" }));
      expect(res.status).toBe(500);
      const body = await res.json();
      expect(body.ok).toBe(false);
      expect(body.error).toMatch(/unable to process/i);
    });

    it("returns 500 when prisma throws on account update", async () => {
      vi.mocked(prisma.account.findUnique).mockResolvedValue(mockAccount);
      vi.mocked(verifyPassword).mockResolvedValue(true);
      vi.mocked(prisma.account.update).mockRejectedValue(new Error("Write failed"));

      const res = await POST(makeRequest({ email: "user@example.com", password: "correct" }));
      expect(res.status).toBe(500);
      const body = await res.json();
      expect(body.ok).toBe(false);
    });
  });
});
